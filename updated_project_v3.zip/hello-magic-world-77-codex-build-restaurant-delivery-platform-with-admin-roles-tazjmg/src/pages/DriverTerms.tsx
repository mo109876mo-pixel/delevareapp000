import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockApi } from "@/lib/mockApi";

const DriverTerms = () => {
  const [content, setContent] = useState<string | null>(null);
  useEffect(() => {
    const load = async () => {
      const settings = await mockApi.getSettings();
      setContent(settings.terms_driver || "");
    };
    load();
  }, []);
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>القوانين والشروط للمندوب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {content === null ? (
              <p>جارٍ التحميل…</p>
            ) : content.trim() ? (
              <pre className="whitespace-pre-wrap text-right">{content}</pre>
            ) : (
              <ul className="list-disc pr-5 space-y-2 text-right">
                <li>الشركة غير مسؤولة عن النزاعات المالية بين المندوب والمطعم.</li>
                <li>المنصة وسيط تقني فقط.</li>
                <li>يحق للإدارة تعليق الحساب عند مخالفة القوانين.</li>
                <li>يمنع تبادل الحسابات.</li>
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverTerms;