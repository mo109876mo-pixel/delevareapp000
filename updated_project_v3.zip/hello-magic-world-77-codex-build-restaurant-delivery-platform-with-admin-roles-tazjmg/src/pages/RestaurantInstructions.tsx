import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockApi } from "@/lib/mockApi";

const RestaurantInstructions = () => {
  const [text, setText] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  useEffect(() => {
    const load = async () => {
      const settings = await mockApi.getSettings();
      setText(settings.instructions_text_restaurant || "");
      setVideoUrl(settings.instructions_video_url_restaurant || "");
    };
    load();
  }, []);
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white p-4">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>تعليمات استخدام التطبيق للمطعم</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {text === null ? (
              <p>جارٍ التحميل…</p>
            ) : text.trim() ? (
              <pre className="whitespace-pre-wrap text-right">{text}</pre>
            ) : (
              <p>لم يقم المسؤول بعد بإعداد تعليمات الاستخدام.</p>
            )}
            {videoUrl && (
              <div className="mt-4">
                <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                  مشاهدة الفيديو التعليمي
                </a>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RestaurantInstructions;