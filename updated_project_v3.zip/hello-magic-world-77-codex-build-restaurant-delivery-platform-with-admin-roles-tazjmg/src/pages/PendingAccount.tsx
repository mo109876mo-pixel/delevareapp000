import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { mockApi } from "@/lib/mockApi";
import { useNavigate, useSearchParams } from "react-router-dom";

const PendingAccount = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const phone = searchParams.get("phone") ?? "";
  const roleParam = searchParams.get("role");
  const role = roleParam === "restaurant" ? "المطعم" : "المندوب";

  const [fullName, setFullName] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);

  // Load registration details from sessionStorage
  useEffect(() => {
    let stored: any = null;
    try {
      const raw = sessionStorage.getItem("pendingAccount");
      stored = raw ? JSON.parse(raw) : null;
    } catch (e) {
      stored = null;
    }
    if (stored && stored.phone === phone) {
      setFullName(stored.fullName || "");
    }
    setLoading(false);
  }, [phone]);

  const handleCancel = async () => {
    const confirmCancel = window.confirm("هل أنت متأكد من إلغاء طلب التسجيل؟");
    if (!confirmCancel) return;
    // Ask the user for their PIN to confirm identity
    const enteredPin = prompt("الرجاء إدخال رمز PIN لإلغاء التسجيل:");
    if (!enteredPin) return;
    try {
      await mockApi.cancelRegistrationSecure(phone, enteredPin);
      toast({ title: "تم إلغاء الطلب", description: "تم حذف طلب التسجيل بنجاح" });
      // Clear the entire session storage
      try {
        sessionStorage.clear();
      } catch (e) {}
      navigate("/");
    } catch (error) {
      toast({
        title: "تعذر الإلغاء",
        description: error instanceof Error ? error.message : "حدث خطأ",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white p-4 flex items-center justify-center">
      <Card className="max-w-lg w-full">
        <CardHeader>
          <CardTitle className="text-center text-2xl text-amber-700">الحساب قيد المراجعة</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {loading ? (
            <p className="text-center">جاري تحميل تفاصيل الحساب…</p>
          ) : (
            <>
              <p className="text-center">تم استلام طلب تسجيل {role} بنجاح.</p>
              <div className="space-y-2 text-right">
                <p>رقم الهاتف: <b>{phone || "-"}</b></p>
                {fullName && <p>الاسم: <b>{fullName}</b></p>}
              </div>
              <p className="text-center text-muted-foreground">سيتم مراجعة الطلب خلال 24-48 ساعة.</p>
              <div className="flex flex-col items-center gap-2 mt-4">
                <Button variant="destructive" onClick={handleCancel} disabled={!phone}>
                  إلغاء الطلب
                </Button>
                <Button onClick={() => navigate("/")}>العودة للصفحة الرئيسية</Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PendingAccount;
