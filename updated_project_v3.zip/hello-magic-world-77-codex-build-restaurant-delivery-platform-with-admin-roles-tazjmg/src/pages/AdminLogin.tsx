import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { setSessionUser } from "@/lib/auth";
import { mockApi } from "@/lib/mockApi";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const AdminLogin = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { toast } = useToast();
  const navigate = useNavigate();

  // Simple client‑side rate limiting: track failed attempts and lock for 30 seconds after 5 failures
  const [attempts, setAttempts] = useState(0);
  const [lockUntil, setLockUntil] = useState(0);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    // If currently locked, refuse login attempts
    if (Date.now() < lockUntil) {
      toast({ title: "محاولات كثيرة", description: "الرجاء الانتظار قليلاً قبل المحاولة مرة أخرى", variant: "destructive" });
      return;
    }

    try {
      const user = await mockApi.adminLogin(username, password);
      setSessionUser({ id: user.id, role: "ADMIN", phone: user.phone, name: user.fullName });
      toast({ title: "تم تسجيل دخول المسؤول" });
      navigate("/admin/dashboard");
      // reset attempts on success
      setAttempts(0);
      setLockUntil(0);
    } catch (error) {
      // log error via mock API for auditing
      const msg = error instanceof Error ? error.message : String(error);
      try {
        await mockApi.logAdminError("admin_login", msg);
      } catch (e) {
        /* ignore logging errors */
      }
      toast({
        title: "بيانات غير صحيحة",
        description: msg || "فشل تسجيل الدخول",
        variant: "destructive",
      });
      // increment attempt counter and apply lock after 5 failed attempts within short period
      setAttempts((prev) => {
        const newCount = prev + 1;
        if (newCount >= 5) {
          setLockUntil(Date.now() + 30_000); // lock for 30 seconds
          return 0;
        }
        return newCount;
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white py-12 px-4">
      <div className="max-w-md mx-auto">
        <Link to="/">
          <Button variant="ghost" className="flex items-center gap-2 mb-6">
            <ArrowLeft className="h-5 w-5" />
            رجوع
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">دخول المسؤول</CardTitle>
          </CardHeader>
          <CardContent>
            {/* لا تعرض أي بيانات اعتماد في الواجهة. استخدم متغيرات بيئة لتحديد بيانات المسؤول. */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="admin-username">اسم المستخدم</Label>
                <Input
                  id="admin-username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="أدخل اسم المستخدم"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="admin-password">كلمة المرور</Label>
                <Input
                  id="admin-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="أدخل الرمز"
                  required
                />
              </div>
              <Button type="submit" className="w-full">دخول</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminLogin;
