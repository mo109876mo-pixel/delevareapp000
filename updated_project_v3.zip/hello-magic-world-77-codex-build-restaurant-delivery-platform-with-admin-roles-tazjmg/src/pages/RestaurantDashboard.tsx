import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { clearSessionUser, getSessionUser } from "@/lib/auth";
import { mockApi } from "@/lib/mockApi";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const RestaurantDashboard = () => {
  const navigate = useNavigate();
  const session = getSessionUser();
  const [orders, setOrders] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  // Order creation fields
  const [fromArea, setFromArea] = useState("");
  const [toArea, setToArea] = useState("");
  const [baseAmount, setBaseAmount] = useState<string>("");
  const [deliveryFee, setDeliveryFee] = useState<string>("");
  const [notes, setNotes] = useState("");

  // رقم هاتف الزبون (اختياري)
  const [customerPhone, setCustomerPhone] = useState<string>("");

  // Support ticket and settings state
  const [supportTitle, setSupportTitle] = useState("");
  const [supportDescription, setSupportDescription] = useState("");
  const [settings, setSettings] = useState<any>({ support_enabled: true });

  const load = async () => {
    if (!session?.id) return;
    const [ordersData, notificationsData, settingsData] = await Promise.all([
      mockApi.listRestaurantOrders(session.id),
      mockApi.listNotificationsForRole("RESTAURANT"),
      mockApi.getSettings(),
    ]);
    setOrders(ordersData);
    setNotifications(notificationsData);
    setSettings(settingsData);
  };

  useEffect(() => {
    if (!session?.id || session.role !== "RESTAURANT") { navigate("/restaurant/login"); return; }
    load();
    const timer = setInterval(load, 3000);
    return () => clearInterval(timer);
  }, [navigate, session?.id, session?.role]);

  const createOrder = async () => {
    if (!session?.id) return;
    // Parse numeric amounts: remove any commas and convert to number
    const parseNumber = (val: string | number): number => {
      if (typeof val === "number") return val;
      const raw = val.replace(/,/g, "");
      const num = parseFloat(raw);
      return isNaN(num) ? 0 : num;
    };
    await mockApi.createOrder(session.id, {
      fromArea,
      toArea,
      customerPhone: customerPhone || undefined,
      baseAmount: parseNumber(baseAmount),
      deliveryFee: parseNumber(deliveryFee),
      notes,
    });
    setFromArea("");
    setToArea("");
    setCustomerPhone("");
    setBaseAmount("");
    setDeliveryFee("");
    setNotes("");
    await load();
  };

  if (!session?.id || session.role !== "RESTAURANT") return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-blue-700">لوحة المطعم</h1>
          <Button variant="outline" onClick={() => { clearSessionUser(); navigate("/"); }}>تسجيل خروج</Button>
        </div>

        <Card><CardHeader><CardTitle>إشعارات الإدارة</CardTitle></CardHeader><CardContent className="space-y-2">
          {notifications.map((notification) => <div key={notification.id} className="border rounded p-2"><p className="font-semibold">{notification.title}</p><p className="text-sm">{notification.body}</p></div>)}
        </CardContent></Card>

        <Card><CardHeader><CardTitle>إنشاء طلب جديد</CardTitle></CardHeader><CardContent className="space-y-3">
          <div>
            <Label>منطقة الالتقاط</Label>
            <Input value={fromArea} onChange={(e) => setFromArea(e.target.value)} placeholder="مثلاً: حي الجامعة" />
          </div>
          <div>
            <Label>منطقة التسليم</Label>
            <Input value={toArea} onChange={(e) => setToArea(e.target.value)} placeholder="مثلاً: حي الإسكان" />
          </div>
          <div>
            <Label>رقم الهاتف (اختياري)</Label>
            <Input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="رقم الهاتف" />
          </div>
          <div>
            <Label>مبلغ الطلب (بدون أجرة التوصيل)</Label>
            <Input
              type="text"
              value={baseAmount}
              onChange={(e) => {
                // Allow free typing; formatting will occur on blur
                setBaseAmount(e.target.value);
              }}
              onBlur={(e) => {
                const raw = e.target.value.replace(/,/g, "").replace(/[^0-9.]/g, "");
                const num = parseFloat(raw);
                if (isNaN(num)) {
                  setBaseAmount("");
                } else {
                  setBaseAmount(num.toLocaleString());
                }
              }}
              placeholder="0"
            />
          </div>
          <div>
            <Label>أجرة التوصيل</Label>
            <Input
              type="text"
              value={deliveryFee}
              onChange={(e) => {
                setDeliveryFee(e.target.value);
              }}
              onBlur={(e) => {
                const raw = e.target.value.replace(/,/g, "").replace(/[^0-9.]/g, "");
                const num = parseFloat(raw);
                if (isNaN(num)) {
                  setDeliveryFee("");
                } else {
                  setDeliveryFee(num.toLocaleString());
                }
              }}
              placeholder="0"
            />
          </div>
          <div>
            <Label>ملاحظات (اختياري)</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="تفاصيل إضافية عن الطلب" />
          </div>
          <Button onClick={createOrder} className="w-full bg-blue-600 hover:bg-blue-700">إرسال الطلب</Button>
        </CardContent></Card>

        <Card><CardHeader><CardTitle>قائمة الطلبات</CardTitle></CardHeader><CardContent className="space-y-3">
          {orders.map((order) => (
            <div key={order.id} className="border rounded-lg p-3 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold">#{order.id}</span>
                <span>{order.status}</span>
              </div>
              {/* Display pickup/dropoff areas and price details instead of customer name and address */}
              <p>من: {order.fromArea} → إلى: {order.toArea}</p>
              <p>المبلغ: {order.baseAmount?.toLocaleString()} - أجرة التوصيل: {order.deliveryFee?.toLocaleString()}</p>
              {order.driver && <p className="text-green-700">المندوب: {order.driver.full_name || order.driver.fullName} - {order.driver.phone}</p>}
              {/* إذا كان الطلب تحت المراجعة بسبب كثرة الدسلايكات، أظهر تنبيه وزر لإعادة فتحه */}
              {order.status === "UNDER_REVIEW" && (
                <>
                  <div className="bg-red-50 text-red-600 p-2 rounded mt-2">
                    تم إخفاء الطلب مؤقتاً لأن عدداً كبيراً من المندوبين يرى أن الأجرة قليلة/غير مناسبة. يرجى تعديل الأجرة أو التفاصيل.
                  </div>
                  <Button
                    variant="secondary"
                    className="mt-2"
                    onClick={async () => {
                      await mockApi.resetOrderVotes(order.id);
                      await load();
                    }}
                  >
                    إعادة فتح الطلب
                  </Button>
                </>
              )}
              <Button variant="outline" className="mt-2" onClick={() => navigate(`/restaurant/orders/${order.id}`)}>تفاصيل الطلب</Button>
            </div>
          ))}
        </CardContent></Card>

        {/* Support ticket creation */}
        <Card>
          <CardHeader>
            <CardTitle>الدعم</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {!settings.support_enabled && <p>الدعم غير متاح حالياً.</p>}
            {settings.support_enabled && (
              <>
                <Input value={supportTitle} onChange={(e) => setSupportTitle(e.target.value)} placeholder="عنوان التذكرة" />
                <Textarea value={supportDescription} onChange={(e) => setSupportDescription(e.target.value)} placeholder="وصف المشكلة" />
                <Button onClick={async () => {
                  if (!supportTitle || !supportDescription) return;
                  await mockApi.createSupportTicket(session.id!, session.role as any, supportTitle, supportDescription);
                  setSupportTitle("");
                  setSupportDescription("");
                  alert("تم إرسال تذكرة الدعم");
                }}>إرسال تذكرة</Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RestaurantDashboard;
