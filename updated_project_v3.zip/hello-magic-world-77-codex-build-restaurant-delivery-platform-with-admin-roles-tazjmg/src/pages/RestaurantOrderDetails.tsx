import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { clearSessionUser, getSessionUser } from "@/lib/auth";
import { mockApi } from "@/lib/mockApi";
import { ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

const RestaurantOrderDetails = () => {
  const session = getSessionUser();
  const navigate = useNavigate();
  const { orderId } = useParams();
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    const load = async () => {
      if (!session?.id || session.role !== "RESTAURANT") { navigate("/restaurant/login"); return; }
      if (!orderId) return;
      setOrder(await mockApi.getOrderForRestaurant(orderId, session.id));
    };
    load();
  }, [session?.id, session?.role, orderId, navigate]);

  if (!session?.id || session.role !== "RESTAURANT") return null;
  if (!order) return <div className="min-h-screen flex items-center justify-center">جاري التحميل...</div>;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <Link to="/restaurant/dashboard"><Button variant="ghost"><ArrowLeft className="h-4 w-4 ml-2" />رجوع</Button></Link>
          <Button variant="outline" onClick={() => { clearSessionUser(); navigate("/"); }}>تسجيل خروج</Button>
        </div>

        <Card><CardHeader><CardTitle>تفاصيل الطلب #{order.id}</CardTitle></CardHeader><CardContent className="space-y-2">
          <p>الحالة: <b>{order.status}</b></p>
          {/* Display the pickup and dropoff areas instead of customer name and phone */}
          <p>من: {order.fromArea} → إلى: {order.toArea}</p>
          {/* Show base amount and delivery fee separately with thousands separators */}
          <p>مبلغ الطلب: {order.baseAmount?.toLocaleString()}</p>
          <p>أجرة التوصيل: {order.deliveryFee?.toLocaleString()}</p>
          {order.notes && <p>ملاحظات: {order.notes}</p>}
          {/* إظهار زر التوجه إلى موقع التسليم إذا كان هناك رابط */}
          {order.destinationLink && (
            <Button
              variant="outline"
              className="mt-2"
              onClick={() => {
                const url = order.destinationLink.startsWith('http')
                  ? order.destinationLink
                  : `https://www.google.com/maps?q=${encodeURIComponent(order.destinationLink)}`;
                window.open(url, '_blank');
              }}
            >
              التوجه للموقع
            </Button>
          )}
        </CardContent></Card>

        <Card><CardHeader><CardTitle>بيانات المندوب</CardTitle></CardHeader><CardContent>
          {order.driver ? <div className="space-y-2"><p>الاسم: {order.driver.full_name || order.driver.fullName}</p><p>الهاتف: {order.driver.phone}</p></div> : <p className="text-muted-foreground">لم يتم تعيين مندوب بعد.</p>}
        </CardContent></Card>
      </div>
    </div>
  );
};

export default RestaurantOrderDetails;
