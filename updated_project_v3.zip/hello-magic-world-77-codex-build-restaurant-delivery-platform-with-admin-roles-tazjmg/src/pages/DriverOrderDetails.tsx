import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { clearSessionUser, getSessionUser } from "@/lib/auth";
import { mockApi } from "@/lib/mockApi";
import { ArrowLeft, Clipboard } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

const DriverOrderDetails = () => {
  const session = getSessionUser();
  const navigate = useNavigate();
  const { orderId } = useParams();
  const [reasonId, setReasonId] = useState("");
  const [notes, setNotes] = useState("");
  const [order, setOrder] = useState<any>(null);
  const [reasons, setReasons] = useState<any[]>([]);

  useEffect(() => {
    const load = async () => {
      if (!session?.id || session.role !== "DRIVER") { navigate("/driver/login"); return; }
      if (!orderId) return;
      setOrder(await mockApi.getOrderForDriver(orderId, session.id));
      setReasons((await mockApi.getCancelReasons()).filter((r: any) => r.is_active ?? r.active));
    };
    load();
  }, [session?.id, session?.role, orderId, navigate]);

  if (!session?.id || session.role !== "DRIVER") return null;
  if (!order) return <div className="min-h-screen flex items-center justify-center">جاري التحميل...</div>;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <Link to="/driver/dashboard"><Button variant="ghost"><ArrowLeft className="h-4 w-4 ml-2" />رجوع</Button></Link>
          <Button variant="outline" onClick={() => { clearSessionUser(); navigate("/"); }}>تسجيل خروج</Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>تفاصيل الطلب #{order.id}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p>الحالة: <b>{order.status}</b></p>
            {/* Restaurant information */}
            <p>المطعم: {order.restaurant?.restaurant_name || order.restaurant?.full_name || order.restaurant?.fullName}</p>
            {order.restaurant?.restaurant_address && <p>الموقع: {order.restaurant.restaurant_address}</p>}
            {/* Show restaurant and customer phones only after pickup; allow copying */}
            {(order.status === 'PICKED_UP' || order.status === 'DELIVERED') && (
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span>هاتف المطعم: {order.restaurant?.restaurant_phone || order.restaurant?.phone}</span>
                  { (order.restaurant?.restaurant_phone || order.restaurant?.phone) && (
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        const phone = order.restaurant?.restaurant_phone || order.restaurant?.phone;
                        if (phone) navigator.clipboard.writeText(phone);
                        alert('تم نسخ الرقم');
                      }}
                    >
                      <Clipboard className="w-4 h-4" />
                    </Button>
                  ) }
                </div>
                {order.customerPhone && (
                  <div className="flex items-center gap-2">
                    <span>رقم الزبون: {order.customerPhone}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        navigator.clipboard.writeText(order.customerPhone);
                        alert('تم نسخ الرقم');
                      }}
                    >
                      <Clipboard className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>
            )}
            {/* Display pickup/dropoff and pricing */}
            <p>من: {order.fromArea} → إلى: {order.toArea}</p>
            <p>مبلغ الطلب: {order.baseAmount?.toLocaleString()}</p>
            <p>أجرة التوصيل: {order.deliveryFee?.toLocaleString()}</p>
            {order.notes && <p>ملاحظات: {order.notes}</p>}
            {/* Show destination link button if provided */}
            {order.destinationLink && (
              <Button
                variant="outline"
                className="mt-2"
                onClick={() => {
                  const url = order.destinationLink.startsWith('http')
                    ? order.destinationLink
                    : `https://www.google.com/maps?q=${encodeURIComponent(order.destinationLink)}`;
                  window.open(url, '_blank');
                }}
              >
                موقع التسليم
              </Button>
            )}
            {/* Button to open restaurant location */}
            {order.restaurant?.restaurant_address && (
              <Button
                variant="outline"
                className="mt-2"
                onClick={() => {
                  const addr = order.restaurant?.restaurant_address;
                  const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}`;
                  window.open(url, '_blank');
                }}
              >
                موقع المطعم
              </Button>
            )}
          </CardContent>
        </Card>

        {order.status === "ASSIGNED" && (
          <Card><CardHeader><CardTitle>إجراءات المندوب</CardTitle></CardHeader><CardContent className="space-y-3">
            <Button onClick={async () => { await mockApi.markPickedUp(order.id, session.id!); navigate("/driver/dashboard"); }}>استلمت</Button>
            <div className="space-y-2 border rounded p-3">
              <Label>سبب الإلغاء</Label>
              <select className="w-full border rounded p-2" value={reasonId} onChange={(e) => setReasonId(e.target.value)}>
                <option value="">اختر السبب</option>
                {reasons.map((reason) => <option key={reason.id} value={reason.id}>{reason.label} (-{reason.penalty_points})</option>)}
              </select>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات" />
              <Button variant="destructive" onClick={async () => { if (!reasonId) return; const reason = await mockApi.getCancelReasonById(reasonId); if (!reason) return; if (!window.confirm(`سوف تخسر ${reason.penalty_points} نقطة. هل أنت متأكد؟`)) return; await mockApi.cancelOrderByDriver(order.id, session.id!, reasonId, notes); navigate('/driver/dashboard'); }}>إلغاء الطلب</Button>
            </div>
          </CardContent></Card>
        )}

        {order.status === "PICKED_UP" && <Button onClick={async () => { await mockApi.markDelivered(order.id, session.id!); navigate('/driver/dashboard'); }}>سلمت</Button>}
      </div>
    </div>
  );
};

export default DriverOrderDetails;
