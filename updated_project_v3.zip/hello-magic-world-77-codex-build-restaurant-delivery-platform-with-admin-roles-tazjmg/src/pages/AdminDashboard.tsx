import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";

import { clearSessionUser, getSessionUser } from "@/lib/auth";
import { mockApi, type OrderStatus } from "@/lib/mockApi";

/**
 * The admin dashboard provides a management interface for approving registrations,
 * editing settings, handling retention and cleanup, managing CMS/support
 * content, processing subscription activations, and viewing orders and analytics.
 *
 * It has been reorganised into tabs to reduce clutter. Each button now
 * surfaces success or error notifications using the toast system. Long running
 * actions disable buttons and show a spinner to indicate progress.
 */
const AdminDashboard = () => {
  const navigate = useNavigate();
  const session = getSessionUser();
  const { toast } = useToast();

  // UI state
  const [tab, setTab] = useState<string>("registrations");
  const [loading, setLoading] = useState<boolean>(false);

  // Data state
  const [rejectReason, setRejectReason] = useState<string>("البيانات غير مكتملة");
  const [newReason, setNewReason] = useState<string>("");
  const [newReasonPenalty, setNewReasonPenalty] = useState<number>(5);
  const [broadcastTitle, setBroadcastTitle] = useState<string>("");
  const [broadcastBody, setBroadcastBody] = useState<string>("");
  const [broadcastTarget, setBroadcastTarget] = useState<"DRIVERS" | "RESTAURANTS" | "ALL">("ALL");
  const [selectedDriver, setSelectedDriver] = useState<string>("");
  const [selectedPlan, setSelectedPlan] = useState<"WEEKLY" | "MONTHLY">("WEEKLY");
  const [amountPaid, setAmountPaid] = useState<number>(0);
  const [orderFilter, setOrderFilter] = useState<"ALL" | OrderStatus>("ALL");
  const [newAdminPassword, setNewAdminPassword] = useState<string>("");
  const [settings, setSettings] = useState<any>({});
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [reasons, setReasons] = useState<any[]>([]);
  const [thresholds, setThresholds] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any>({});
  const [drivers, setDrivers] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [cleanupLogs, setCleanupLogs] = useState<any[]>([]);
  const [activationRequests, setActivationRequests] = useState<any[]>([]);
  const [supportTickets, setSupportTickets] = useState<any[]>([]);

  // Support ticket conversation state.  When an admin selects a ticket from the
  // list below, the details and message thread will be loaded into these
  // state variables.  The replyMessage holds the text of a new reply.
  const [activeTicket, setActiveTicket] = useState<any>(null);
  const [ticketMessages, setTicketMessages] = useState<any[]>([]);
  const [replyMessage, setReplyMessage] = useState<string>("");

  // Load all relevant admin data concurrently
  const load = async () => {
    try {
      const [settingsData, registrationsData, reasonsData, thresholdsData, analyticsData, driversData, ordersData, logsData, activationReqs, supportTicketsData] =
        await Promise.all([
          mockApi.getSettings(),
          mockApi.getRegistrations(),
          mockApi.getCancelReasons(),
          mockApi.getTrustThresholds(),
          mockApi.getAnalytics(),
          mockApi.getDrivers(),
          mockApi.listOrdersForAdmin(orderFilter),
          mockApi.getCleanupLogs(),
          mockApi.getActivationRequests(),
          mockApi.getSupportTickets(),
        ]);
      setSettings(settingsData);
      setRegistrations(registrationsData);
      setReasons(reasonsData);
      setThresholds(thresholdsData);
      setAnalytics(analyticsData);
      setDrivers(driversData);
      setOrders(ordersData);
      setCleanupLogs(logsData);
      setActivationRequests(activationReqs);
      setSupportTickets(supportTicketsData);
    } catch (error: any) {
      toast({ title: "خطأ في التحميل", description: error?.message ?? String(error), variant: "destructive" });
    }
  };

  // Access control: redirect non-admin to login page
  useEffect(() => {
    if (!session || session.role !== "ADMIN") {
      navigate("/secure-admin-city-portal-2026");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  // Load data on mount and whenever orderFilter changes
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderFilter]);

  // Periodically refresh data every few seconds so that admin actions taken
  // elsewhere (e.g. by other tabs or users) are reflected without a manual
  // reload.  This interval is cleared on unmount to avoid leaks.
  useEffect(() => {
    const interval = setInterval(() => {
      load();
    }, 5000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderFilter]);

  // Guard: do not render anything before session check passes
  if (!session || session.role !== "ADMIN") return null;

  // Helper to wrap async actions with loading state and toasts
  /**
   * Helper to execute an async action with consistent loading state, toast
   * notifications, data refresh, and audit logging.  Pass an optional
   * actionName to log the action in admin_actions_log and in case of error
   * the error is logged via admin_error_logs.  Optionally include a targetId
   * and meta object for richer audit records.
   */
  const runAction = async (
    action: () => Promise<void>,
    successMessage?: string,
    actionName?: string,
    targetId?: string | null,
    meta?: any
  ) => {
    setLoading(true);
    try {
      await action();
      if (successMessage) {
        toast({ title: successMessage });
      }
      // Log success if actionName provided
      if (actionName) {
        await mockApi.logAdminAction(actionName, targetId, meta);
      }
      await load();
    } catch (error: any) {
      // Log error if actionName provided
      if (actionName) {
        await mockApi.logAdminError(actionName, error?.message ?? String(error));
      }
      toast({ title: "حدث خطأ", description: error?.message ?? String(error), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // Registration handlers
  const handleApproveRegistration = (id: string) =>
    runAction(() => mockApi.approveRegistration(id), "تمت الموافقة على الحساب", "approve_registration", id);
  const handleRejectRegistration = (id: string) =>
    runAction(() => mockApi.rejectRegistration(id, rejectReason), "تم رفض التسجيل", "reject_registration", id);

  // Cancel reason handler
  const handleAddReason = () =>
    runAction(async () => {
      if (!newReason) throw new Error("الرجاء إدخال سبب");
      await mockApi.createCancelReason(newReason, newReasonPenalty);
      setNewReason("");
      setNewReasonPenalty(5);
    }, "تم إضافة سبب جديد", "add_cancel_reason");

  // Settings handlers
  const handleSaveSettings = () =>
    runAction(() => mockApi.updateSettings(settings), "تم حفظ الإعدادات", "update_settings");
  const handleRunPickupJob = () =>
    runAction(() => mockApi.enforcePickupTimeoutJob(), "تم تشغيل مهمة المهلة", "run_pickup_job");
  const handleRunCleanup = () =>
    runAction(() => mockApi.cleanupOldRecords(), "تم تشغيل التنظيف", "run_cleanup");

  // Support & CMS settings save (same as general settings)
  const handleSaveCms = () =>
    runAction(() => mockApi.updateSettings(settings), "تم حفظ المحتوى", "update_cms");

  // Manual subscription activation
  const handleActivateSubscription = () =>
    runAction(
      async () => {
        if (!selectedDriver) throw new Error("اختر السائق");
        await mockApi.activateSubscription(selectedDriver, selectedPlan, amountPaid, "manual activation");
        setSelectedDriver("");
        setAmountPaid(0);
      },
      "تم تفعيل الاشتراك",
      "manual_activate_subscription",
      selectedDriver,
      { plan: selectedPlan, amountPaid }
    );

  // Broadcast
  const handleBroadcast = () =>
    runAction(
      async () => {
        await mockApi.broadcast(broadcastTarget, broadcastTitle, broadcastBody);
        setBroadcastTitle("");
        setBroadcastBody("");
      },
      "تم إرسال الرسالة",
      "broadcast",
      null,
      { target: broadcastTarget }
    );

  // Activation request handlers
  const handleApproveActivationRequest = (req: any) =>
    runAction(
      async () => {
        const days = req.plan_type === "WEEKLY" ? 7 : 30;
        await mockApi.approveActivationRequest(String(req.id), days);
      },
      "تم قبول طلب التفعيل",
      "approve_activation_request",
      String(req.id)
    );
  const handleRejectActivationRequest = (req: any) => {
    const note = window.prompt("سبب الرفض:") || "";
    return runAction(
      () => mockApi.rejectActivationRequest(String(req.id), note),
      "تم رفض طلب التفعيل",
      "reject_activation_request",
      String(req.id)
    );
  };

  // Support ticket status update
  const handleUpdateTicketStatus = (ticketId: string, status: "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED") =>
    runAction(
      () => mockApi.updateSupportTicketStatus(String(ticketId), status),
      "تم تحديث حالة التذكرة",
      "update_ticket_status",
      ticketId,
      { status }
    );

  // When a ticket row is clicked, load its messages and set it as the active ticket
  const handleSelectTicket = async (ticket: any) => {
    setActiveTicket(ticket);
    try {
      const msgs = await mockApi.getSupportMessages(String(ticket.id));
      setTicketMessages(Array.isArray(msgs) ? msgs : []);
    } catch (err: any) {
      toast({ title: "خطأ في تحميل الرسائل", description: err?.message ?? String(err), variant: "destructive" });
      setTicketMessages([]);
    }
  };

  // Send a reply message to the currently active support ticket
  const handleSendReply = async () => {
    if (!activeTicket || !replyMessage) return;
    try {
      await mockApi.addSupportMessage(String(activeTicket.id), "ADMIN", replyMessage);
      setReplyMessage("");
      const msgs = await mockApi.getSupportMessages(String(activeTicket.id));
      setTicketMessages(Array.isArray(msgs) ? msgs : []);
      toast({ title: "تم إرسال الرد" });
    } catch (err: any) {
      toast({ title: "خطأ في إرسال الرد", description: err?.message ?? String(err), variant: "destructive" });
    }
  };

  // Helper for spinner inside buttons
  const renderButtonContent = (text: string) => (
    loading ? (
      <>
        <Loader2 className="animate-spin" /> {text}
      </>
    ) : (
      text
    )
  );

  // Change admin password
  const handleChangeAdminPassword = () =>
    runAction(
      async () => {
        if (!newAdminPassword) throw new Error("الرجاء إدخال كلمة مرور جديدة");
        await mockApi.changeAdminPassword(newAdminPassword);
        setNewAdminPassword("");
      },
      "تم تغيير كلمة المرور",
      "change_admin_password"
    );

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-purple-800">لوحة الإدارة</h1>
          <Button variant="outline" onClick={() => { clearSessionUser(); navigate("/"); }}>تسجيل خروج</Button>
        </div>

        {/* Tabs navigation */}
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-9 gap-1">
            <TabsTrigger value="registrations">التسجيلات</TabsTrigger>
            <TabsTrigger value="reasons">أسباب الإلغاء</TabsTrigger>
            <TabsTrigger value="settings">الإعدادات</TabsTrigger>
            <TabsTrigger value="retention">الاحتفاظ والتنظيف</TabsTrigger>
            <TabsTrigger value="cms">المحتوى والدعم</TabsTrigger>
            <TabsTrigger value="activation">التفعيل والاشتراكات</TabsTrigger>
            <TabsTrigger value="tickets">تذاكر الدعم</TabsTrigger>
            <TabsTrigger value="orders">الطلبات</TabsTrigger>
            <TabsTrigger value="analytics">التحليلات والإشعارات</TabsTrigger>
          </TabsList>

          {/* Registrations tab */}
          <TabsContent value="registrations">
            <Card>
              <CardHeader><CardTitle>طلبات التسجيل الجديدة</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <Input value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="سبب الرفض الافتراضي" />
                {registrations.filter((r) => r.status === "PENDING").map((item) => (
                  <div key={item.id} className="border rounded p-3 space-y-2">
                    <p><b>{item.type === "DRIVER" ? "سائق" : "مطعم"}</b> - {item.fullName} - {item.phone}</p>
                    <div className="flex gap-2 flex-wrap">
                      <Button disabled={loading} onClick={() => handleApproveRegistration(item.id)}>{renderButtonContent("قبول")}</Button>
                      <Button variant="destructive" disabled={loading} onClick={() => handleRejectRegistration(item.id)}>{renderButtonContent("رفض")}</Button>
                    </div>
                  </div>
                ))}
                {!registrations.filter((r) => r.status === "PENDING").length && (
                  <p className="text-muted-foreground">لا توجد طلبات تسجيل جديدة.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cancel reasons tab */}
          <TabsContent value="reasons">
            <Card>
              <CardHeader><CardTitle>أسباب الإلغاء والعقوبات</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {reasons.map((reason) => (
                  <div key={reason.id} className="border rounded p-2 text-sm">
                    {reason.label} - penalty: {reason.penalty_points}
                  </div>
                ))}
                <div className="grid sm:grid-cols-3 gap-2">
                  <Input value={newReason} onChange={(e) => setNewReason(e.target.value)} placeholder="سبب جديد" />
                  <Input type="number" value={newReasonPenalty} onChange={(e) => setNewReasonPenalty(Number(e.target.value))} />
                  <Button disabled={loading} onClick={handleAddReason}>{renderButtonContent("إضافة سبب")}</Button>
                </div>
                <div className="space-y-2 border-t pt-2">
                  <h3 className="font-semibold">عتبات الثقة</h3>
                  {thresholds.map((t) => (
                    <div key={t.id} className="text-sm">score &lt;= {t.score_lte} → {t.action_type || t.action}</div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader><CardTitle>الإعدادات العامة</CardTitle></CardHeader>
              <CardContent className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                  <Label>مدة المهلة لالتقاط الطلب (دقيقة)</Label>
                  <Input type="number" value={settings.pickup_timeout_minutes ?? 10} onChange={(e) => setSettings({ ...settings, pickup_timeout_minutes: Number(e.target.value) })} />
                </div>
                <div>
                  <Label>نقاط العقوبة عند تجاوز المهلة</Label>
                  <Input type="number" value={settings.timeout_penalty_points ?? 10} onChange={(e) => setSettings({ ...settings, timeout_penalty_points: Number(e.target.value) })} />
                </div>
                <div>
                  <Label>أيام التجربة المجانية</Label>
                  <Input type="number" value={settings.free_trial_days ?? 3} onChange={(e) => setSettings({ ...settings, free_trial_days: Number(e.target.value) })} />
                </div>
                <div className="flex items-end gap-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" checked={!!settings.free_trial_enabled} onChange={(e) => setSettings({ ...settings, free_trial_enabled: e.target.checked })} />
                    تفعيل التجربة المجانية
                  </label>
                </div>
                <div>
                  <Label>حد الدسلايكات</Label>
                  <Input type="number" value={settings.dislike_threshold ?? 5} onChange={(e) => setSettings({ ...settings, dislike_threshold: Number(e.target.value) })} />
                </div>
                {/* Admin password change */}
                <div>
                  <Label>كلمة مرور المسؤول الجديدة</Label>
                  <Input
                    type="password"
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                    placeholder="أدخل كلمة مرور جديدة"
                  />
                </div>
                <div className="sm:col-span-2 flex flex-wrap gap-2">
                  <Button disabled={loading} onClick={handleSaveSettings}>{renderButtonContent("حفظ الإعدادات")}</Button>
                  <Button variant="secondary" disabled={loading} onClick={handleRunPickupJob}>{renderButtonContent("تشغيل مهمة المهلة الآن")}</Button>
                  <Button
                    variant="outline"
                    disabled={loading || !newAdminPassword}
                    onClick={handleChangeAdminPassword}
                  >
                    {renderButtonContent("تغيير كلمة المرور")}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Retention and cleanup tab */}
          <TabsContent value="retention">
            <Card>
              <CardHeader><CardTitle>إعدادات الاحتفاظ بالبيانات</CardTitle></CardHeader>
              <CardContent className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                  <Label>مدة الاحتفاظ بسجلات المطعم (يوم)</Label>
                  <Input type="number" value={settings.order_retention_days_restaurant ?? 7} onChange={(e) => setSettings({ ...settings, order_retention_days_restaurant: Number(e.target.value) })} />
                </div>
                <div>
                  <Label>مدة الاحتفاظ بسجلات المندوب (يوم)</Label>
                  <Input type="number" value={settings.order_retention_days_driver ?? 7} onChange={(e) => setSettings({ ...settings, order_retention_days_driver: Number(e.target.value) })} />
                </div>
                <div>
                  <Label>مدة الاحتفاظ بسجلات الأدمن (يوم)</Label>
                  <Input type="number" value={settings.order_retention_days_admin ?? 14} onChange={(e) => setSettings({ ...settings, order_retention_days_admin: Number(e.target.value) })} />
                </div>
                <div>
                  <Label>مدة الاحتفاظ باللايك/الدسلايك (يوم)</Label>
                  <Input type="number" value={settings.votes_retention_days ?? ''} onChange={(e) => setSettings({ ...settings, votes_retention_days: e.target.value ? Number(e.target.value) : null })} />
                </div>
                <div>
                  <Label>مدة الاحتفاظ بسجل النقاط (يوم)</Label>
                  <Input type="number" value={settings.points_retention_days ?? ''} onChange={(e) => setSettings({ ...settings, points_retention_days: e.target.value ? Number(e.target.value) : null })} />
                </div>
                <div>
                  <Label>تكرار التنظيف</Label>
                  <select className="border rounded p-2 w-full" value={settings.cleanup_frequency ?? 'DAILY'} onChange={(e) => setSettings({ ...settings, cleanup_frequency: e.target.value })}>
                    <option value="DAILY">يومي</option>
                    <option value="WEEKLY">أسبوعي</option>
                    <option value="DISABLED">تعطيل</option>
                  </select>
                </div>
                <div className="sm:col-span-3 flex gap-2">
                  <Button disabled={loading} onClick={handleSaveSettings}>{renderButtonContent("حفظ الإعدادات")}</Button>
                  <Button variant="secondary" disabled={loading} onClick={handleRunCleanup}>{renderButtonContent("تشغيل التنظيف الآن")}</Button>
                </div>
              </CardContent>
            </Card>
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>سجل عمليات التنظيف</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {cleanupLogs.map((log) => (
                  <div key={log.id} className="border rounded p-2 text-sm">
                    <p>وقت التشغيل: {new Date(log.run_at).toLocaleString()}</p>
                    <p>الطلبات المؤرشفة: {log.orders_archived ?? 0}</p>
                    <p>اللايكات/الدسلايكات المحذوفة: {log.votes_deleted ?? 0}</p>
                    <p>سجلات النقاط المحذوفة: {log.points_deleted ?? 0}</p>
                  </div>
                ))}
                {!cleanupLogs.length && <p className="text-muted-foreground">لا توجد عمليات تنظيف مسجلة.</p>}
              </CardContent>
            </Card>
          </TabsContent>

          {/* CMS & Support tab */}
          <TabsContent value="cms">
            <Card>
              <CardHeader><CardTitle>المحتوى والسياسات والدعم</CardTitle></CardHeader>
              <CardContent className="grid sm:grid-cols-2 gap-3">
                <div className="flex items-end gap-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" checked={!!settings.support_enabled} onChange={(e) => setSettings({ ...settings, support_enabled: e.target.checked })} />
                    تفعيل نظام الدعم
                  </label>
                </div>
                <div>
                  <Label>رقم التحويل للدفع</Label>
                  <Input value={settings.payment_number ?? ''} onChange={(e) => setSettings({ ...settings, payment_number: e.target.value })} />
                </div>
                <div>
                  <Label>رابط فيديو كيفية الدفع</Label>
                  <Input value={settings.payment_howto_video_url ?? ''} onChange={(e) => setSettings({ ...settings, payment_howto_video_url: e.target.value })} />
                </div>
                <div className="sm:col-span-2">
                  <Label>سياسة الخصوصية للسائق</Label>
                  <Textarea value={settings.privacy_policy_driver ?? ''} onChange={(e) => setSettings({ ...settings, privacy_policy_driver: e.target.value })} />
                </div>
                <div className="sm:col-span-2">
                  <Label>سياسة الخصوصية للمطعم</Label>
                  <Textarea value={settings.privacy_policy_restaurant ?? ''} onChange={(e) => setSettings({ ...settings, privacy_policy_restaurant: e.target.value })} />
                </div>
                <div className="sm:col-span-2">
                  <Label>الشروط والأحكام للسائق</Label>
                  <Textarea value={settings.terms_driver ?? ''} onChange={(e) => setSettings({ ...settings, terms_driver: e.target.value })} />
                </div>
                <div className="sm:col-span-2">
                  <Label>الشروط والأحكام للمطعم</Label>
                  <Textarea value={settings.terms_restaurant ?? ''} onChange={(e) => setSettings({ ...settings, terms_restaurant: e.target.value })} />
                </div>
                <div className="sm:col-span-2">
                  <Label>تعليمات السائق (نص)</Label>
                  <Textarea value={settings.instructions_text_driver ?? ''} onChange={(e) => setSettings({ ...settings, instructions_text_driver: e.target.value })} />
                </div>
                <div>
                  <Label>رابط فيديو تعليمات السائق</Label>
                  <Input value={settings.instructions_video_url_driver ?? ''} onChange={(e) => setSettings({ ...settings, instructions_video_url_driver: e.target.value })} />
                </div>
                <div className="sm:col-span-2">
                  <Label>تعليمات المطعم (نص)</Label>
                  <Textarea value={settings.instructions_text_restaurant ?? ''} onChange={(e) => setSettings({ ...settings, instructions_text_restaurant: e.target.value })} />
                </div>
                <div>
                  <Label>رابط فيديو تعليمات المطعم</Label>
                  <Input value={settings.instructions_video_url_restaurant ?? ''} onChange={(e) => setSettings({ ...settings, instructions_video_url_restaurant: e.target.value })} />
                </div>
                <div className="sm:col-span-2 flex gap-2">
                  <Button disabled={loading} onClick={handleSaveCms}>{renderButtonContent("حفظ المحتوى")}</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activation & subscriptions tab */}
          <TabsContent value="activation">
            <Card>
              <CardHeader><CardTitle>إدارة الاشتراكات اليدوية</CardTitle></CardHeader>
              <CardContent className="grid sm:grid-cols-4 gap-2">
                <select className="border rounded p-2" value={selectedDriver} onChange={(e) => setSelectedDriver(e.target.value)}>
                  <option value="">اختر السائق</option>
                  {drivers.map((driver) => (
                    <option key={driver.id} value={driver.id}>{driver.fullName} - {driver.phone}</option>
                  ))}
                </select>
                <select className="border rounded p-2" value={selectedPlan} onChange={(e) => setSelectedPlan(e.target.value as "WEEKLY" | "MONTHLY")}>                
                  <option value="WEEKLY">أسبوعي</option>
                  <option value="MONTHLY">شهري</option>
                </select>
                <Input type="number" value={amountPaid} onChange={(e) => setAmountPaid(Number(e.target.value))} placeholder="المبلغ" />
                <Button disabled={loading} onClick={handleActivateSubscription}>{renderButtonContent("تفعيل")}</Button>
              </CardContent>
            </Card>
            <Card className="mt-4">
              <CardHeader><CardTitle>طلبات تفعيل الاشتراك</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {activationRequests.map((req) => (
                  <div key={req.id} className="border rounded p-3 space-y-1 text-sm">
                    <p>رقم السائق: {req.driver_id}</p>
                    <p>الخطة: {req.plan_type}</p>
                    {req.screenshot_url && (
                      <p>لقطة التحويل: <a href={req.screenshot_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">رابط</a></p>
                    )}
                    {req.note && <p>ملاحظات: {req.note}</p>}
                    <p>الحالة: {req.status}</p>
                    {req.status === "PENDING" && (
                      <div className="flex flex-wrap gap-2 mt-1">
                        <Button disabled={loading} onClick={() => handleApproveActivationRequest(req)}>{renderButtonContent("قبول")}</Button>
                        <Button variant="destructive" disabled={loading} onClick={() => handleRejectActivationRequest(req)}>{renderButtonContent("رفض")}</Button>
                      </div>
                    )}
                    {req.status !== "PENDING" && req.admin_note && <p>ملاحظة المسؤول: {req.admin_note}</p>}
                  </div>
                ))}
                {!activationRequests.length && <p className="text-muted-foreground">لا توجد طلبات تفعيل.</p>}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support tickets tab */}
          <TabsContent value="tickets">
            <Card>
              <CardHeader><CardTitle>تذاكر الدعم</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {supportTickets.map((ticket) => (
                  <div key={ticket.id} className="border rounded p-3 space-y-1 text-sm">
                    {/* Display the reporter's name and phone if available via joined user record */}
                    <p>
                      المستخدم: {ticket.user?.full_name ?? ticket.user?.fullName ?? ticket.user_id} ({ticket.user_role})
                      {ticket.user?.phone && ` - ${ticket.user.phone}`}
                    </p>
                    <p>العنوان: {ticket.title}</p>
                    <p>الوصف: {ticket.description}</p>
                    <p>الحالة: {ticket.status}</p>
                    {ticket.admin_note && <p>ملاحظة المسؤول: {ticket.admin_note}</p>}
                    {ticket.status !== "CLOSED" && (
                      <div className="flex gap-2 flex-wrap mt-1">
                        {/* View conversation button */}
                        <Button variant="outline" onClick={() => handleSelectTicket(ticket)}>عرض المحادثة</Button>
                        {ticket.status !== "IN_PROGRESS" && (
                          <Button disabled={loading} onClick={() => handleUpdateTicketStatus(String(ticket.id), "IN_PROGRESS")}>{renderButtonContent("قيد المعالجة")}</Button>
                        )}
                        {ticket.status !== "RESOLVED" && (
                          <Button variant="secondary" disabled={loading} onClick={() => handleUpdateTicketStatus(String(ticket.id), "RESOLVED")}>{renderButtonContent("تم الحل")}</Button>
                        )}
                        {ticket.status !== "CLOSED" && (
                          <Button variant="destructive" disabled={loading} onClick={() => handleUpdateTicketStatus(String(ticket.id), "CLOSED")}>{renderButtonContent("إغلاق")}</Button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                {!supportTickets.length && <p className="text-muted-foreground">لا توجد تذاكر دعم.</p>}
              </CardContent>
            </Card>
            {/* Conversation panel for a selected support ticket.  When a ticket is
                selected via the "عرض المحادثة" button above, its details and
                message thread will be displayed here. */}
            {activeTicket && (
              <div className="mt-4 border rounded p-3 space-y-2 text-sm">
                <h3 className="font-bold">التذكرة #{activeTicket.id}</h3>
                <p>
                  المستخدم: {activeTicket.user?.full_name ?? activeTicket.user?.fullName ?? activeTicket.user_id} ({activeTicket.user_role})
                  {activeTicket.user?.phone && ` - ${activeTicket.user.phone}`}
                </p>
                <p>العنوان: {activeTicket.title}</p>
                <p>الوصف: {activeTicket.description}</p>
                {/* Message thread */}
                <div className="border rounded p-2 max-h-40 overflow-y-auto space-y-1">
                  {ticketMessages.map((msg: any) => (
                    <p key={msg.id} className="border-b pb-1"><b>{msg.sender_role}:</b> {msg.message}</p>
                  ))}
                  {!ticketMessages.length && <p className="text-muted-foreground">لا توجد رسائل.</p>}
                </div>
                <Textarea value={replyMessage} onChange={(e) => setReplyMessage(e.target.value)} placeholder="اكتب ردك هنا" />
                <Button onClick={handleSendReply} disabled={!replyMessage.trim()}>إرسال الرد</Button>
              </div>
            )}
          </TabsContent>

          {/* Orders tab */}
          <TabsContent value="orders">
            <Card>
              <CardHeader><CardTitle>الطلبات</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <select className="border rounded p-2 w-full" value={orderFilter} onChange={(e) => setOrderFilter(e.target.value as "ALL" | OrderStatus)}>
                  <option value="ALL">الكل</option>
                  <option value="AVAILABLE">متاحة</option>
                  <option value="ASSIGNED">معينة</option>
                  <option value="PICKED_UP">تم الاستلام</option>
                  <option value="DELIVERED">تم التوصيل</option>
                  <option value="CANCELED_BY_DRIVER">ملغاة من السائق</option>
                  <option value="CANCELED_BY_RESTAURANT">ملغاة من المطعم</option>
                </select>
                {orders.map((order) => (
                  <div key={order.id} className="border rounded p-3 space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>#{order.id}</span>
                      <span>{order.status}</span>
                    </div>
                    <p>المطعم: {order.restaurant?.full_name ?? order.restaurant?.fullName ?? "-"}</p>
                    <p>المندوب: {order.driver?.full_name ?? order.driver?.fullName ?? "غير معين"}</p>
                    {/* Show pickup/dropoff areas and pricing details instead of the old
                       customer name/phone and address fields.  Fallback to the
                       legacy fields when new ones are absent. */}
                    <p>منطقة الالتقاط: {order.fromArea ?? order.customerName}</p>
                    <p>منطقة التسليم: {order.toArea ?? order.customerPhone}</p>
                    <p>مبلغ الطلب: {Number(order.baseAmount ?? order.amount)?.toLocaleString()}</p>
                    <p>أجرة التوصيل: {Number(order.deliveryFee ?? 0)?.toLocaleString()}</p>
                  </div>
                ))}
                {!orders.length && <p className="text-muted-foreground">لا توجد طلبات.</p>}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics & broadcast tab */}
          <TabsContent value="analytics">
            <Card>
              <CardHeader><CardTitle>إحصائيات بسيطة</CardTitle></CardHeader>
              <CardContent className="grid sm:grid-cols-3 gap-3 text-sm">
                <div className="border p-3 rounded">طلبات اليوم: {analytics.ordersToday ?? 0}</div>
                <div className="border p-3 rounded">تم التوصيل اليوم: {analytics.deliveredToday ?? 0}</div>
                <div className="border p-3 rounded">طلبات الشهر: {analytics.ordersMonth ?? 0}</div>
                <div className="border p-3 rounded">السائقون النشطون: {analytics.activeDrivers ?? 0}</div>
                <div className="border p-3 rounded">الاشتراكات النشطة: {analytics.activeSubscriptions ?? 0}</div>
                <div className="border p-3 rounded">دخل الاشتراكات: {analytics.subscriptionsIncomeTotal ?? 0}</div>
              </CardContent>
            </Card>
            <Card className="mt-4">
              <CardHeader><CardTitle>إرسال إشعار جماعي</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                <select className="border rounded p-2 w-full" value={broadcastTarget} onChange={(e) => setBroadcastTarget(e.target.value as "DRIVERS" | "RESTAURANTS" | "ALL")}>                  
                  <option value="DRIVERS">السائقين</option>
                  <option value="RESTAURANTS">المطاعم</option>
                  <option value="ALL">الجميع</option>
                </select>
                <Input value={broadcastTitle} onChange={(e) => setBroadcastTitle(e.target.value)} placeholder="العنوان" />
                <Textarea value={broadcastBody} onChange={(e) => setBroadcastBody(e.target.value)} placeholder="المحتوى" />
                <Button disabled={loading} onClick={handleBroadcast}>{renderButtonContent("إرسال")}</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;