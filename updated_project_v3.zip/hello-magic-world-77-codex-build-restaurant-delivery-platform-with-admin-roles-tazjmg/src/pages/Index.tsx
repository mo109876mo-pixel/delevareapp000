import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Store, Truck } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-16 text-center">
        {/* Update platform branding */}
        <h1 className="text-4xl md:text-6xl font-bold text-blue-600 mb-4">منصة توصيل البريق</h1>
        <p className="text-muted-foreground mb-10">منصة توصيل البريق لخدمة التوصيل داخل المدينة</p>

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <Card className="hover:shadow-lg transition-shadow bg-white border-blue-100">
            <CardHeader>
              <CardTitle className="text-xl flex items-center justify-center gap-2 text-blue-600">
                <Truck className="h-6 w-6" /> تسجيل مندوب
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate("/driver/auth")} className="w-full bg-blue-600 hover:bg-blue-700">
                متابعة
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow bg-white border-blue-100">
            <CardHeader>
              <CardTitle className="text-xl flex items-center justify-center gap-2 text-blue-600">
                <Store className="h-6 w-6" /> تسجيل مطعم
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate("/restaurant/auth")} className="w-full bg-blue-600 hover:bg-blue-700">
                متابعة
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Index;
