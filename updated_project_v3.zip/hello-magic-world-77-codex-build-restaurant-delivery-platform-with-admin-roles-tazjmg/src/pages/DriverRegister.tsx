import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { mockApi } from "@/lib/mockApi";
import { ArrowLeft, Upload } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const DriverRegister = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [city, setCity] = useState("");
  const [area, setArea] = useState("");
  const [idCardFile, setIdCardFile] = useState<File | null>(null);
  const [selfieFile, setSelfieFile] = useState<File | null>(null);

  // Checkbox for agreeing to terms/privacy
  const [agreed, setAgreed] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!idCardFile || !selfieFile) {
      toast({ title: "يرجى رفع المستندات", variant: "destructive" });
      return;
    }

    if (!agreed) {
      toast({ title: "يرجى الموافقة على الشروط والأحكام", variant: "destructive" });
      return;
    }

    try {
      await mockApi.registerDriver({
        fullName,
        phone,
        pin,
        city,
        area,
        idCardImageName: idCardFile.name,
        selfieImageName: selfieFile.name,
      });

      // Store minimal registration details (without PIN) in sessionStorage so that the pending page can display them without exposing sensitive info via query string.
      try {
        sessionStorage.setItem(
          "pendingAccount",
          JSON.stringify({ role: "driver", phone, fullName })
        );
      } catch (e) {
        // ignore if sessionStorage is unavailable
      }

      toast({ title: "تم إرسال الطلب", description: "الحالة الآن: PENDING حتى موافقة الإدارة" });
      navigate(`/pending?role=driver&phone=${phone}`);
    } catch (error) {
      toast({
        title: "تعذر إرسال الطلب",
        description: error instanceof Error ? error.message : "حدث خطأ",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* App heading and description */}
        <div className="mb-4 text-center">
          <h2 className="text-3xl font-bold text-blue-800">منصة توصيل</h2>
          <p className="mt-1 text-sm text-gray-600">طلبك سيُراجع من الإدارة قبل تفعيل الحساب.</p>
        </div>
        <Link to="/driver/auth">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="h-5 w-5 ml-2" /> رجوع
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle className="text-center text-2xl text-blue-700">تسجيل مندوب جديد</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>الاسم الثلاثي</Label>
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required />
              </div>
              <div>
                <Label>رقم الهاتف</Label>
                <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </div>
              <div>
                <Label>PIN (8)</Label>
                <Input type="password" value={pin} onChange={(e) => setPin(e.target.value)} minLength={8} maxLength={8} required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>المدينة (اختياري)</Label>
                  <Input value={city} onChange={(e) => setCity(e.target.value)} />
                </div>
                <div>
                  <Label>المنطقة (اختياري)</Label>
                  <Input value={area} onChange={(e) => setArea(e.target.value)} />
                </div>
              </div>

              <div>
                <Label>صورة البطاقة الموحدة</Label>
                <label className="border rounded-md p-3 flex items-center gap-2 cursor-pointer">
                  <Upload className="h-4 w-4" />
                  <span>{idCardFile?.name ?? "اختيار ملف"}</span>
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => setIdCardFile(e.target.files?.[0] ?? null)} required />
                </label>
              </div>

              <div>
                <Label>صورة شخصية (سيلفي)</Label>
                <label className="border rounded-md p-3 flex items-center gap-2 cursor-pointer">
                  <Upload className="h-4 w-4" />
                  <span>{selfieFile?.name ?? "اختيار ملف"}</span>
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => setSelfieFile(e.target.files?.[0] ?? null)} required />
                </label>
              </div>

              {/* Agreement checkbox and links */}
              <div className="flex flex-col gap-2">
                <label className="inline-flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={agreed}
                    onChange={(e) => setAgreed(e.target.checked)}
                    className="h-4 w-4 border-gray-300 rounded"
                    required
                  />
                <span>أوافق على الشروط وسياسة الخصوصية</span>
                </label>
                <div className="flex gap-4 text-sm text-blue-600 underline">
                  <Link to="/driver/terms" target="_blank">قراءة الشروط والأحكام</Link>
                  <Link to="/driver/privacy" target="_blank">قراءة سياسة الخصوصية</Link>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!agreed}
              >
                إرسال طلب التسجيل
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverRegister;
