import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
// Import Textarea component for support ticket description input
import { Textarea } from "@/components/ui/textarea";
import { clearSessionUser, getSessionUser } from "@/lib/auth";
import { mockApi } from "@/lib/mockApi";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const DriverDashboard = () => {
  const session = getSessionUser();
  const navigate = useNavigate();
  const [selectedReason, setSelectedReason] = useState("");
  const [cancelNotes, setCancelNotes] = useState("");
  const [blockedReason, setBlockedReason] = useState("");
  const [availableOrders, setAvailableOrders] = useState<any[]>([]);
  const [activeOrders, setActiveOrders] = useState<any[]>([]);
  const [reasons, setReasons] = useState<any[]>([]);
  const [status, setStatus] = useState<any>({ trustScore: 0, subscriptionDaysRemaining: 0 });
  const [notifications, setNotifications] = useState<any[]>([]);

  // Paywall and support ticket state
  const [activationPlan, setActivationPlan] = useState<"WEEKLY" | "MONTHLY">("WEEKLY");
  const [activationScreenshotUrl, setActivationScreenshotUrl] = useState("");
  const [activationNote, setActivationNote] = useState("");
  const [supportTitle, setSupportTitle] = useState("");
  const [supportDescription, setSupportDescription] = useState("");
  const [settings, setSettings] = useState<any>({ support_enabled: true, payment_number: "", payment_howto_video_url: "" });

  // Like/dislike state: mapping order id to vote (true=like, false=dislike, undefined=no vote)
  const [userVotes, setUserVotes] = useState<Record<string, boolean | null>>({});
  // Aggregate counts of likes and dislikes per order
  const [voteCounts, setVoteCounts] = useState<Record<string, { likes: number; dislikes: number }>>({});

  const load = async () => {
    if (!session?.id) return;
    const [available, active, reasonsData, statusData, notificationsData, settingsData] = await Promise.all([
      mockApi.listAvailableOrders(session.id),
      mockApi.listDriverActiveOrders(session.id),
      mockApi.getCancelReasons(),
      mockApi.getDriverStatus(session.id),
      mockApi.listNotificationsForRole("DRIVER"),
      mockApi.getSettings(),
    ]);
    setBlockedReason(available.blockedReason);
    setAvailableOrders(available.orders);
    setActiveOrders(active);
    setReasons(reasonsData.filter((item: any) => item.is_active ?? item.active));
    setStatus(statusData);
    setNotifications(notificationsData);
    setSettings(settingsData);

    // Load like/dislike votes for available orders
    const ordersList = available.orders;
    try {
      const votesByUser = await mockApi.getUserVotes(session.id!);
      const userVoteMap: Record<string, boolean | null> = {};
      if (Array.isArray(votesByUser)) {
        votesByUser.forEach((v: any) => {
          userVoteMap[String(v.order_id)] = v.is_like;
        });
      }
      setUserVotes(userVoteMap);

      const counts: Record<string, { likes: number; dislikes: number }> = {};
      await Promise.all(
        ordersList.map(async (order: any) => {
          const votes = await mockApi.getOrderVotes(order.id);
          let likes = 0;
          let dislikes = 0;
          if (Array.isArray(votes)) {
            votes.forEach((v: any) => {
              if (v.is_like) likes++;
              else dislikes++;
            });
          }
          counts[String(order.id)] = { likes, dislikes };
        })
      );
      setVoteCounts(counts);
    } catch (err) {
      // ignore vote loading errors
    }
  };

  useEffect(() => {
    if (!session?.id || session.role !== "DRIVER") { navigate("/driver/login"); return; }
    load();
    const timer = setInterval(load, 3000);
    return () => clearInterval(timer);
  }, [navigate, session?.id, session?.role]);

  // Handle like/dislike vote. Upserts vote and refreshes list.
  const handleVote = async (orderId: string, isLike: boolean) => {
    if (!session?.id) return;
    try {
      await mockApi.recordOrderVote(orderId, session.id, isLike);
      await load();
    } catch (error) {
      // ignore
    }
  };

  if (!session?.id || session.role !== "DRIVER") return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-blue-700">لوحة المندوب</h1>
          <Button variant="outline" onClick={() => { clearSessionUser(); navigate("/"); }}>تسجيل خروج</Button>
        </div>

        <Card><CardHeader><CardTitle>حالتي الحالية</CardTitle></CardHeader><CardContent className="grid sm:grid-cols-4 gap-3">
          <div className="border rounded p-3">Trust Score: {status.trustScore}</div>
          <div className="border rounded p-3">Banned Until: {status.bannedUntil ?? "غير مبند"}</div>
          <div className="border rounded p-3">أيام الاشتراك: {status.subscriptionDaysRemaining}</div>
          <div className="border rounded p-3">Subscription: {status.subscriptionActive ? "Active" : "Inactive"}</div>
        </CardContent></Card>

        {/* Paywall: show activation form when subscription inactive */}
        {!status.subscriptionActive && (
          <Card>
            <CardHeader>
              <CardTitle>تفعيل الاشتراك</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p>اشتراكك غير فعال. يرجى اختيار خطة ودفع المبلغ عبر رقم التحويل أدناه، ثم رفع لقطة الشاشة لتفعيل الاشتراك.</p>
              <div>
                <Label>الخطة</Label>
                <select className="border rounded p-2 w-full" value={activationPlan} onChange={(e) => setActivationPlan(e.target.value as "WEEKLY" | "MONTHLY") }>
                  <option value="WEEKLY">أسبوعي</option>
                  <option value="MONTHLY">شهري</option>
                </select>
              </div>
              {settings.payment_number && <p>رقم التحويل: <b>{settings.payment_number}</b></p>}
              {settings.payment_howto_video_url && (
                <a href={settings.payment_howto_video_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">شلون أحول؟</a>
              )}
              <Input value={activationScreenshotUrl} onChange={(e) => setActivationScreenshotUrl(e.target.value)} placeholder="رابط لقطة التحويل (صورة)" />
              <Input value={activationNote} onChange={(e) => setActivationNote(e.target.value)} placeholder="ملاحظات إضافية (اختياري)" />
              <Button onClick={async () => {
                await mockApi.createActivationRequest(session.id!, activationPlan, activationScreenshotUrl || null, activationNote || null);
                setActivationScreenshotUrl("");
                setActivationNote("");
                alert("تم إرسال طلب التفعيل. سيقوم المسؤول بمراجعته.");
                await load();
              }}>إرسال طلب التفعيل</Button>
            </CardContent>
          </Card>
        )}

        {status.subscriptionActive && (
          <Card><CardHeader><CardTitle>إشعارات الإدارة</CardTitle></CardHeader><CardContent className="space-y-2">
            {notifications.map((n) => <div key={n.id} className="border rounded p-2"><p className="font-semibold">{n.title}</p><p className="text-sm">{n.body}</p></div>)}
            {!notifications.length && <p className="text-muted-foreground">لا توجد إشعارات حالياً.</p>}
          </CardContent></Card>
        )}

        {status.subscriptionActive && (
          <Card><CardHeader><CardTitle>طلباتي الحالية</CardTitle></CardHeader><CardContent className="space-y-3">
            {activeOrders.map((order) => (
              <div key={order.id} className="border rounded p-3 space-y-2">
                <div className="flex justify-between"><span>#{order.id}</span><span>{order.status}</span></div>
                {/* Display pickup and dropoff areas instead of customer name/phone */}
                <p>من: {order.fromArea} → إلى: {order.toArea}</p>
                {/* Show the base amount and delivery fee with thousands separators */}
                <p>المبلغ: {order.baseAmount?.toLocaleString()} - أجرة التوصيل: {order.deliveryFee?.toLocaleString()}</p>
                <div className="flex gap-2 flex-wrap">
                  <Button variant="outline" onClick={() => navigate(`/driver/orders/${order.id}`)}>تفاصيل الطلب</Button>
                  {order.status === "ASSIGNED" && <Button onClick={async () => { await mockApi.markPickedUp(order.id, session.id!); await load(); }}>استلمت</Button>}
                  {order.status !== "DELIVERED" && <Button onClick={async () => { await mockApi.markDelivered(order.id, session.id!); await load(); }} variant="secondary">سلمت</Button>}
                </div>
                {order.status === "ASSIGNED" && (
                  <div className="border rounded p-2 mt-2 space-y-2">
                    <Label>سبب الإلغاء</Label>
                    <select className="w-full border rounded p-2" value={selectedReason} onChange={(event) => setSelectedReason(event.target.value)}>
                      <option value="">اختر السبب</option>
                      {reasons.map((reason: any) => <option key={reason.id} value={reason.id}>{reason.label} (-{reason.penalty_points})</option>)}
                    </select>
                    <Input value={cancelNotes} onChange={(event) => setCancelNotes(event.target.value)} placeholder="ملاحظات" />
                    <Button variant="destructive" onClick={async () => {
                      if (!selectedReason) return;
                      const reason = await mockApi.getCancelReasonById(selectedReason); if (!reason) return;
                      if (!window.confirm(`سوف تخسر ${reason.penalty_points} نقطة ثقة. هل تريد التأكيد؟`)) return;
                      await mockApi.cancelOrderByDriver(order.id, session.id!, selectedReason, cancelNotes); setCancelNotes(""); await load();
                    }}>إلغاء الطلب</Button>
                  </div>
                )}
              </div>
            ))}
          </CardContent></Card>
        )}

        {status.subscriptionActive && (
          <Card>
            <CardHeader><CardTitle>الطلبات المتاحة</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {blockedReason && <p className="text-red-600">{blockedReason}</p>}
              {availableOrders.map((order) => (
                <div key={order.id} className="border rounded p-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <span>#{order.id}</span>
                    <span>{order.status}</span>
                  </div>
                    {/* Display pickup and dropoff areas instead of customer name/phone */}
                    <p>من: {order.fromArea} → إلى: {order.toArea}</p>
                    {/* Show the base amount and delivery fee with thousands separators */}
                    <p>المبلغ: {order.baseAmount?.toLocaleString()} - أجرة التوصيل: {order.deliveryFee?.toLocaleString()}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-2">
                      <Button
                        variant={userVotes[order.id] === true ? "default" : "outline"}
                        onClick={() => handleVote(order.id, true)}
                        disabled={!!blockedReason}
                      >
                        👍 {voteCounts[order.id]?.likes ?? 0}
                      </Button>
                      <Button
                        variant={userVotes[order.id] === false ? "destructive" : "outline"}
                        onClick={() => handleVote(order.id, false)}
                        disabled={!!blockedReason}
                      >
                        👎 {voteCounts[order.id]?.dislikes ?? 0}
                      </Button>
                      <Button
                        onClick={async () => {
                          const ok = await mockApi.claimOrderAtomic(order.id, session.id!);
                          if (!ok) alert("تم أخذ الطلب من مندوب آخر");
                          await load();
                        }}
                        disabled={!!blockedReason}
                      >
                        أخذ الطلب
                      </Button>
                    </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Support ticket creation */}
        <Card>
          <CardHeader>
            <CardTitle>الدعم</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {!settings.support_enabled && <p>الدعم غير متاح حالياً.</p>}
            {settings.support_enabled && (
              <>
                <Input value={supportTitle} onChange={(e) => setSupportTitle(e.target.value)} placeholder="عنوان التذكرة" />
                <Textarea value={supportDescription} onChange={(e) => setSupportDescription(e.target.value)} placeholder="وصف المشكلة" />
                <Button onClick={async () => {
                  if (!supportTitle || !supportDescription) return;
                  await mockApi.createSupportTicket(session.id!, session.role as any, supportTitle, supportDescription);
                  setSupportTitle("");
                  setSupportDescription("");
                  alert("تم إرسال تذكرة الدعم");
                }}>إرسال تذكرة</Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverDashboard;
