import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const DriverAuth = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4">
      <div className="max-w-md mx-auto">
        <Link to="/">
          <Button variant="ghost" className="flex items-center gap-2 mb-6">
            <ArrowLeft className="h-5 w-5" />
            رجوع
          </Button>
        </Link>

        <Card className="border-blue-100">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-blue-600">
              حساب المندوب
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => navigate("/driver/login")}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              عندك حساب؟ تسجيل الدخول
            </Button>
            <Button
              onClick={() => navigate("/driver/register")}
              variant="outline"
              className="w-full"
            >
              إنشاء حساب جديد
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverAuth;