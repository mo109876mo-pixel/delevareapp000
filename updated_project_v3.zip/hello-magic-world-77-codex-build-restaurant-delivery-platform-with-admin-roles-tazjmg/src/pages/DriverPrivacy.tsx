import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockApi } from "@/lib/mockApi";

const DriverPrivacy = () => {
  const [content, setContent] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      const settings = await mockApi.getSettings();
      setContent(settings.privacy_policy_driver || "");
    };
    load();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>سياسة الخصوصية للمندوب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {content === null ? (
              <p>جارٍ التحميل…</p>
            ) : content.trim() ? (
              <pre className="whitespace-pre-wrap text-right">{content}</pre>
            ) : (
              <p>لم يقم المسؤول بعد بإعداد سياسة الخصوصية.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverPrivacy;