import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { mockApi } from "@/lib/mockApi";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const RestaurantRegister = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [city, setCity] = useState("");
  const [area, setArea] = useState("");
  const [restaurantName, setRestaurantName] = useState("");
  const [restaurantPhone, setRestaurantPhone] = useState("");
  const [restaurantAddress, setRestaurantAddress] = useState("");
  const [notes, setNotes] = useState("");

  // الموقع الإلكتروني للمطعم (اختياري)
  const [websiteUrl, setWebsiteUrl] = useState("");

  // Checkbox for agreeing to terms/privacy
  const [agreed, setAgreed] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!agreed) {
      toast({ title: "يرجى الموافقة على الشروط والأحكام", variant: "destructive" });
      return;
    }
    try {
      await mockApi.registerRestaurant({
        fullName,
        phone,
        pin,
        city,
        area,
        restaurantName,
        restaurantPhone,
        restaurantAddress,
        notes,
        websiteUrl,
      });
      // Store minimal registration details (without PIN) in sessionStorage so that the pending page can display them without exposing sensitive info via query string.
      try {
        sessionStorage.setItem(
          "pendingAccount",
          JSON.stringify({ role: "restaurant", phone, fullName })
        );
      } catch (e) {
        // ignore if sessionStorage is unavailable
      }

      toast({ title: "تم إرسال طلب المطعم", description: "الحالة الآن: PENDING" });
      navigate(`/pending?role=restaurant&phone=${phone}`);
    } catch (error) {
      toast({
        title: "تعذر إرسال الطلب",
        description: error instanceof Error ? error.message : "حدث خطأ",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* App heading and description */}
        <div className="mb-4 text-center">
          <h2 className="text-3xl font-bold text-blue-800">منصة توصيل</h2>
          <p className="mt-1 text-sm text-gray-600">طلبك سيُراجع من الإدارة قبل تفعيل الحساب.</p>
        </div>
        <Link to="/restaurant/auth">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="h-5 w-5 ml-2" /> رجوع
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle className="text-center text-2xl text-blue-700">تسجيل مطعم جديد</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>الاسم الثلاثي</Label>
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required />
              </div>
              <div>
                <Label>رقم الهاتف</Label>
                <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </div>
              <div>
                <Label>PIN (8)</Label>
                <Input type="password" value={pin} onChange={(e) => setPin(e.target.value)} minLength={8} maxLength={8} required />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>المدينة (اختياري)</Label>
                  <Input value={city} onChange={(e) => setCity(e.target.value)} />
                </div>
                <div>
                  <Label>المنطقة (اختياري)</Label>
                  <Input value={area} onChange={(e) => setArea(e.target.value)} />
                </div>
              </div>

              <div>
                <Label>اسم المطعم</Label>
                <Input value={restaurantName} onChange={(e) => setRestaurantName(e.target.value)} required />
              </div>
              <div>
                <Label>هاتف المطعم</Label>
                <Input type="tel" value={restaurantPhone} onChange={(e) => setRestaurantPhone(e.target.value)} required />
              </div>
              <div>
                <Label>عنوان المطعم</Label>
                <Textarea value={restaurantAddress} onChange={(e) => setRestaurantAddress(e.target.value)} required />
              </div>
              <div>
                <Label>رابط موقع المطعم (اختياري)</Label>
                <Input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  placeholder="https://example.com"
                />
              </div>
              <div>
                <Label>ملاحظات/صور (اختياري)</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
              </div>

              {/* Agreement checkbox and links */}
              <div className="flex flex-col gap-2">
                <label className="inline-flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={agreed}
                    onChange={(e) => setAgreed(e.target.checked)}
                    className="h-4 w-4 border-gray-300 rounded"
                    required
                  />
                  <span>أوافق على الشروط وسياسة الخصوصية</span>
                </label>
                <div className="flex gap-4 text-sm text-blue-600 underline">
                  <Link to="/restaurant/terms" target="_blank">قراءة الشروط والأحكام</Link>
                  <Link to="/restaurant/privacy" target="_blank">قراءة سياسة الخصوصية</Link>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!agreed}
              >
                إرسال طلب التسجيل
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RestaurantRegister;
