import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { setSessionUser } from "@/lib/auth";
import { mockApi } from "@/lib/mockApi";
import { ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

const DriverLogin = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    try {
      const user = await mockApi.login(phone, pin, "DRIVER");
      setSessionUser({ id: user.id, role: "DRIVER", phone: user.phone, name: user.fullName });
      toast({ title: "تم تسجيل الدخول بنجاح" });
      navigate("/driver/dashboard");
    } catch (error) {
      const message = error instanceof Error ? error.message : "تحقق من البيانات";
      if (message.includes("قيد المراجعة")) {
        navigate(`/pending?role=driver&phone=${phone}`);
        return;
      }

      toast({
        title: "تعذر تسجيل الدخول",
        description: message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4">
      <div className="max-w-md mx-auto">
        <Link to="/driver/auth">
          <Button variant="ghost" className="flex items-center gap-2 mb-6">
            <ArrowLeft className="h-5 w-5" />
            رجوع
          </Button>
        </Link>

        <Card className="border-blue-100">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-blue-600">تسجيل دخول المندوب</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone">رقم الهاتف</Label>
                <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pin">PIN من 8 أرقام/رموز</Label>
                <Input id="pin" type="password" value={pin} onChange={(e) => setPin(e.target.value)} minLength={8} required />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">تسجيل الدخول</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverLogin;
