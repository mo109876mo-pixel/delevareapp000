import RoleGuard from "@/components/auth/RoleGuard";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogin from "./pages/AdminLogin";
import DriverAuth from "./pages/DriverAuth";
import DriverDashboard from "./pages/DriverDashboard";
import DriverLogin from "./pages/DriverLogin";
import DriverRegister from "./pages/DriverRegister";
import DriverOrderDetails from "./pages/DriverOrderDetails";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import PendingAccount from "./pages/PendingAccount";
import RestaurantAuth from "./pages/RestaurantAuth";
import RestaurantDashboard from "./pages/RestaurantDashboard";
import RestaurantLogin from "./pages/RestaurantLogin";
import RestaurantOrderDetails from "./pages/RestaurantOrderDetails";
import RestaurantRegister from "./pages/RestaurantRegister";
import DriverPrivacy from "./pages/DriverPrivacy";
import DriverTerms from "./pages/DriverTerms";
import DriverInstructions from "./pages/DriverInstructions";
import RestaurantPrivacy from "./pages/RestaurantPrivacy";
import RestaurantTerms from "./pages/RestaurantTerms";
import RestaurantInstructions from "./pages/RestaurantInstructions";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <div dir="rtl">
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/restaurant/auth" element={<RestaurantAuth />} />
            <Route path="/restaurant/login" element={<RestaurantLogin />} />
            <Route path="/restaurant/register" element={<RestaurantRegister />} />
            <Route
              path="/restaurant/orders/:orderId"
              element={
                <RoleGuard role="RESTAURANT">
                  <RestaurantOrderDetails />
                </RoleGuard>
              }
            />
            <Route
              path="/restaurant/dashboard"
              element={
                <RoleGuard role="RESTAURANT">
                  <RestaurantDashboard />
                </RoleGuard>
              }
            />

            {/* Public policy and instructions pages for restaurants */}
            <Route path="/restaurant/privacy" element={<RestaurantPrivacy />} />
            <Route path="/restaurant/terms" element={<RestaurantTerms />} />
            <Route path="/restaurant/instructions" element={<RestaurantInstructions />} />
            <Route path="/driver/auth" element={<DriverAuth />} />
            <Route path="/driver/login" element={<DriverLogin />} />
            <Route path="/driver/register" element={<DriverRegister />} />
            <Route
              path="/driver/orders/:orderId"
              element={
                <RoleGuard role="DRIVER">
                  <DriverOrderDetails />
                </RoleGuard>
              }
            />
            <Route
              path="/driver/dashboard"
              element={
                <RoleGuard role="DRIVER">
                  <DriverDashboard />
                </RoleGuard>
              }
            />

            {/* Public policy and instructions pages for drivers */}
            <Route path="/driver/privacy" element={<DriverPrivacy />} />
            <Route path="/driver/terms" element={<DriverTerms />} />
            <Route path="/driver/instructions" element={<DriverInstructions />} />
            <Route path="/secure-admin-city-portal-2026" element={<AdminLogin />} />
            <Route path="/pending" element={<PendingAccount />} />
            <Route
              path="/admin/dashboard"
              element={
                <RoleGuard role="ADMIN">
                  <AdminDashboard />
                </RoleGuard>
              }
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </div>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
