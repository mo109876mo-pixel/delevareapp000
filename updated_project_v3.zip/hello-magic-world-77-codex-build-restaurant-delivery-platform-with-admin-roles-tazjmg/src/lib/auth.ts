export type AppRole = "ADMIN" | "DRIVER" | "RESTAURANT";

export interface SessionUser {
  id?: string;
  role: AppRole;
  phone: string;
  name: string;
}

const SESSION_KEY = "sessionUser";

export const setSessionUser = (session: SessionUser) => {
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
};

export const getSessionUser = (): SessionUser | null => {
  const raw = localStorage.getItem(SESSION_KEY);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as SessionUser;
  } catch {
    return null;
  }
};

export const clearSessionUser = () => {
  localStorage.removeItem(SESSION_KEY);
};
