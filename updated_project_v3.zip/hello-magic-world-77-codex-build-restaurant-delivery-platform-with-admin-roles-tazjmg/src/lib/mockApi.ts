export type Role = "ADMIN" | "RESTAURANT" | "DRIVER";
export type OrderStatus = "AVAILABLE" | "ASSIGNED" | "PICKED_UP" | "DELIVERED" | "CANCELED_BY_DRIVER" | "CANCELED_BY_RESTAURANT";

// Admin credentials are provided via environment variables. Do not hardcode secrets in source code.
const ADMIN_USERNAME: string = (import.meta.env.VITE_ADMIN_USERNAME as string) || "";
const ADMIN_PASSWORD: string = (import.meta.env.VITE_ADMIN_PASSWORD as string) || "";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

const apiHeaders = {
  apikey: SUPABASE_ANON_KEY,
  Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
  "Content-Type": "application/json",
};

const ensureEnv = () => {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    throw new Error("Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY");
  }
};

const hashPin = async (pin: string) => {
  const data = new TextEncoder().encode(pin);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
};

/**
 * Safely parse a fetch Response as JSON. Supabase RPC endpoints often return
 * `void` responses (HTTP 204) which cause `Response.json()` to throw an
 * "Unexpected end of JSON input" error. This helper reads the response
 * body as text first; when empty it returns `null`. If non‑empty it
 * attempts to parse JSON, catching any errors and returning `null`
 * instead. In both cases callers can treat a `null` return value as
 * "no payload" without exceptions being thrown.
 */
const safeJson = async (res: Response): Promise<any | null> => {
  // 204 No Content is the most common case for void RPCs
  if (res.status === 204) return null;
  const text = await res.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch (err) {
    // If the body isn't valid JSON return null; callers should handle nulls
    return null;
  }
};

const request = async (path: string, init?: RequestInit) => {
  ensureEnv();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...init,
    headers: { ...apiHeaders, ...(init?.headers || {}) },
  });
  if (!res.ok) {
    // Always read the error body to surface meaningful messages
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  return safeJson(res);
};

// Helper to build query params from object (null/undefined values are skipped)
const buildQuery = (obj: Record<string, any>) => {
  return Object.entries(obj)
    .filter(([, v]) => v !== undefined && v !== null)
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join('&');
};

const rpc = async (fn: string, body: Record<string, unknown>) => {
  ensureEnv();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: apiHeaders,
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  // Use safeJson to avoid unexpected JSON parse errors for void returns
  return safeJson(res);
};

const nowIso = () => new Date().toISOString();

export const mockApi = {
  async registerDriver(payload: { fullName: string; phone: string; pin: string; city?: string; area?: string; idCardImageName: string; selfieImageName: string; }) {
    const pinHash = await hashPin(payload.pin);
    await request("registrations", {
      method: "POST",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({
        type: "DRIVER",
        full_name: payload.fullName,
        phone: payload.phone,
        pin_hash: pinHash,
        city: payload.city || null,
        area: payload.area || null,
        id_card_image_path: payload.idCardImageName,
        selfie_image_path: payload.selfieImageName,
        status: "PENDING",
      }),
    });
  },

  async registerRestaurant(payload: { fullName: string; phone: string; pin: string; city?: string; area?: string; restaurantName: string; restaurantAddress: string; restaurantPhone: string; notes?: string; websiteUrl?: string; }) {
    const pinHash = await hashPin(payload.pin);
    await request("registrations", {
      method: "POST",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({
        type: "RESTAURANT",
        full_name: payload.fullName,
        phone: payload.phone,
        pin_hash: pinHash,
        city: payload.city || null,
        area: payload.area || null,
        restaurant_name: payload.restaurantName,
        restaurant_address: payload.restaurantAddress,
        restaurant_phone: payload.restaurantPhone,
        restaurant_notes: payload.notes || null,
        website_url: payload.websiteUrl || null,
        status: "PENDING",
      }),
    });
  },

  async adminLogin(username: string, password: string) {
    // Attempt to check hashed admin password from settings table first.  If the
    // column is null, fallback to environment variables for development
    // convenience.  We also record each login attempt via record_admin_login_attempt
    // to enable rate‑limiting on the server.
    try {
      // record the attempt as unsuccessful by default; we'll update success later
      await rpc("record_admin_login_attempt", { p_username: username, p_success: false });
    } catch (e) {
      // ignore logging errors silently
    }
    // Fetch admin_password_hash if present
    let settings: any;
    try {
      const rows = await request("settings?id=eq.1&select=admin_password_hash");
      settings = rows && rows[0] ? rows[0] : {};
    } catch (e) {
      settings = {};
    }
    const hashedFromDb: string | null = settings?.admin_password_hash || null;
    if (hashedFromDb) {
      // verify hashed password
      const passHash = await hashPin(password);
      if (username !== ADMIN_USERNAME && username !== "admin") throw new Error("بيانات المسؤول غير صحيحة");
      if (passHash !== hashedFromDb) throw new Error("بيانات المسؤول غير صحيحة");
    } else {
      // Fallback to environment variables
      if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) throw new Error("بيانات المسؤول غير صحيحة");
    }
    // record success after passing validation
    try {
      await rpc("record_admin_login_attempt", { p_username: username, p_success: true });
    } catch (e) {
      /* ignore */
    }
    return { id: "admin-local", role: "ADMIN" as Role, fullName: "مسؤول المنصة", phone: "-" };
  },

  async login(phone: string, pin: string, role: Role) {
    const pending = await request(`registrations?phone=eq.${encodeURIComponent(phone)}&status=eq.PENDING&select=id`);
    if (Array.isArray(pending) && pending.length) throw new Error("الحساب قيد المراجعة");

    const users = await request(`users?phone=eq.${encodeURIComponent(phone)}&role=eq.${role}&status=eq.APPROVED&select=*`);
    if (!Array.isArray(users) || !users.length) throw new Error("لا يوجد حساب معتمد بهذه البيانات");
    const user = users[0];
    const pinHash = await hashPin(pin);
    if (user.pin_hash !== pinHash) throw new Error("PIN غير صحيح");
    return { id: String(user.id), role: user.role as Role, fullName: user.full_name, phone: user.phone };
  },

  async getRegistrations() {
    const rows = await request("registrations?order=created_at.desc&select=*");
    return rows.map((r: any) => ({
      id: String(r.id),
      type: r.type,
      fullName: r.full_name,
      phone: r.phone,
      status: r.status,
      idCardImageName: r.id_card_image_path,
      selfieImageName: r.selfie_image_path,
      restaurantName: r.restaurant_name,
      restaurantAddress: r.restaurant_address,
    }));
  },

  async approveRegistration(registrationId: string) {
    await rpc("approve_registration", { p_registration_id: Number(registrationId) });
  },

  async rejectRegistration(registrationId: string, reason: string) {
    await request(`registrations?id=eq.${registrationId}`, {
      method: "PATCH",
      body: JSON.stringify({ status: "REJECTED", reject_reason: reason }),
    });
  },

  async getCancelReasons() { return request("cancel_reasons?is_active=eq.true&select=*&order=id.asc"); },
  async createCancelReason(label: string, penalty_points: number) {
    await request("cancel_reasons", { method: "POST", body: JSON.stringify({ label, penalty_points, is_active: true }) });
  },
  async getCancelReasonById(reasonId: string) {
    const rows = await request(`cancel_reasons?id=eq.${reasonId}&select=*`);
    return rows[0] ?? null;
  },
  async getTrustThresholds() { return request("trust_thresholds?select=*&order=score_lte.asc"); },

  async getSettings() {
    const rows = await request("settings?id=eq.1&select=*");
    const s = rows[0] || {};
    return {
      pickup_timeout_minutes: s.pickup_timeout_minutes ?? 10,
      timeout_penalty_points: s.timeout_penalty_points ?? 10,
      free_trial_enabled: s.free_trial_enabled ?? true,
      free_trial_days: s.free_trial_days ?? 3,
      dislike_threshold: s.dislike_threshold ?? 5,
      order_retention_days_restaurant: s.order_retention_days_restaurant ?? 7,
      order_retention_days_driver: s.order_retention_days_driver ?? 7,
      order_retention_days_admin: s.order_retention_days_admin ?? 14,
      votes_retention_days: s.votes_retention_days ?? null,
      points_retention_days: s.points_retention_days ?? null,
      cleanup_frequency: s.cleanup_frequency ?? 'DAILY',
      support_enabled: s.support_enabled ?? true,
      payment_number: s.payment_number ?? '',
      payment_howto_video_url: s.payment_howto_video_url ?? '',
      privacy_policy_driver: s.privacy_policy_driver ?? '',
      privacy_policy_restaurant: s.privacy_policy_restaurant ?? '',
      terms_driver: s.terms_driver ?? '',
      terms_restaurant: s.terms_restaurant ?? '',
      instructions_text_driver: s.instructions_text_driver ?? '',
      instructions_video_url_driver: s.instructions_video_url_driver ?? '',
      instructions_text_restaurant: s.instructions_text_restaurant ?? '',
      instructions_video_url_restaurant: s.instructions_video_url_restaurant ?? '',
    };
  },
  async updateSettings(newSettings: Record<string, unknown>) {
    await request("settings?id=eq.1", { method: "PATCH", body: JSON.stringify(newSettings) });
  },

  /**
   * Execute the cleanup job immediately.
   */
  async cleanupOldRecords() {
    await rpc("cleanup_old_records", {});
  },

  /**
   * Retrieve cleanup logs.
   */
  async getCleanupLogs() {
    return request("cleanup_logs?select=*&order=run_at.desc");
  },

  async getDrivers() {
    const rows = await request("users?role=eq.DRIVER&status=eq.APPROVED&select=id,full_name,phone");
    return rows.map((r: any) => ({ id: String(r.id), fullName: r.full_name, phone: r.phone }));
  },

  async activateSubscription(driverId: string, plan: "WEEKLY" | "MONTHLY", amountPaid: number, paymentNote?: string) {
    await request(`subscriptions?driver_id=eq.${driverId}`, { method: "PATCH", body: JSON.stringify({ is_active: false }) });
    const days = plan === "WEEKLY" ? 7 : 30;
    const end = new Date(); end.setDate(end.getDate() + days);
    await request("subscriptions", {
      method: "POST",
      body: JSON.stringify({
        driver_id: Number(driverId), plan, start_at: nowIso(), end_at: end.toISOString(), is_active: true,
        amount_paid: amountPaid, payment_note: paymentNote || null,
      }),
    });
  },

  async broadcast(target: "DRIVERS" | "RESTAURANTS" | "ALL", title: string, body: string) {
    await request("notifications", { method: "POST", body: JSON.stringify({ target, title, body }) });
  },

  async listNotificationsForRole(role: Role) {
    const target = role === "DRIVER" ? "DRIVERS" : role === "RESTAURANT" ? "RESTAURANTS" : "ALL";
    return request(`notifications?or=(target.eq.ALL,target.eq.${target})&order=created_at.desc&select=*`);
  },

  /**
   * Create a new order for a restaurant.  The caller must provide the
   * pickup and dropoff areas, the base price of the order (what the
   * customer pays the restaurant) and the delivery fee paid to the
   * driver.  An optional notes field can be used for any special
   * instructions.  A destinationLink may also be provided to allow the
   * driver to navigate to the dropoff location.  The backend stores
   * from_area/to_area as both customer_name/customer_phone for
   * backwards‑compatibility and in dedicated columns; amount and
   * base_amount are set to the base price and the fee is stored in
   * delivery_fee.
   */
  async createOrder(
    restaurantId: string,
    payload: {
      fromArea: string;
      toArea: string;
      customerPhone?: string;
      baseAmount: number;
      deliveryFee: number;
      notes?: string;
    }
  ) {
    await request("orders", {
      method: "POST",
      body: JSON.stringify({
        restaurant_id: Number(restaurantId),
        // Store from/to areas in dedicated columns; preserve backwards compatibility
        customer_name: payload.fromArea,
        customer_phone: payload.customerPhone || "",
        address_text: payload.notes ?? "",
        amount: payload.baseAmount,
        base_amount: payload.baseAmount,
        delivery_fee: payload.deliveryFee,
        from_area: payload.fromArea,
        to_area: payload.toArea,
        notes: payload.notes || null,
        // Do not include destination_link as the restaurant does not provide a map link
        status: "AVAILABLE",
      }),
    });
  },

  async listRestaurantOrders(restaurantId: string) {
    const orders = await request(
      `orders?restaurant_id=eq.${restaurantId}&is_archived=eq.false&order=created_at.desc&select=*`
    );
    const users = await request("users?select=id,full_name,phone");
    return orders.map((o: any) => {
      const fromArea = o.from_area ?? o.customer_name;
      const toArea = o.to_area ?? o.customer_phone;
      const baseAmount = o.base_amount !== null && o.base_amount !== undefined ? Number(o.base_amount) : Number(o.amount);
      const deliveryFee = o.delivery_fee !== null && o.delivery_fee !== undefined ? Number(o.delivery_fee) : 0;
      return {
        ...o,
        id: String(o.id),
        // Backwards compatibility: expose both old and new field names
        customerName: o.customer_name,
        customerPhone: o.customer_phone,
        addressText: o.address_text,
        destinationLink: o.destination_link,
        fromArea,
        toArea,
        baseAmount,
        deliveryFee,
        driver: o.driver_id ? users.find((u: any) => u.id === o.driver_id) : undefined,
      };
    });
  },

  async listOrdersForAdmin(status: "ALL" | OrderStatus = "ALL") {
    const filter = status === "ALL" ? "" : `&status=eq.${status}`;
    const orders = await request(`orders?select=*&is_archived=eq.false&order=created_at.desc${filter}`);
    const users = await request("users?select=id,full_name,phone");
    return orders.map((o: any) => {
      const fromArea = o.from_area ?? o.customer_name;
      const toArea = o.to_area ?? o.customer_phone;
      const baseAmount = o.base_amount !== null && o.base_amount !== undefined ? Number(o.base_amount) : Number(o.amount);
      const deliveryFee = o.delivery_fee !== null && o.delivery_fee !== undefined ? Number(o.delivery_fee) : 0;
      return {
        ...o,
        id: String(o.id),
        customerName: o.customer_name,
        customerPhone: o.customer_phone,
        addressText: o.address_text,
        destinationLink: o.destination_link,
        fromArea,
        toArea,
        baseAmount,
        deliveryFee,
        restaurant: users.find((u: any) => u.id === o.restaurant_id),
        driver: o.driver_id ? users.find((u: any) => u.id === o.driver_id) : undefined,
      };
    });
  },

  async listDriverActiveOrders(driverId: string) {
    const orders = await request(
      `orders?driver_id=eq.${driverId}&is_archived=eq.false&or=(status.eq.ASSIGNED,status.eq.PICKED_UP)&order=created_at.desc&select=*`
    );
    return orders.map((o: any) => {
      const fromArea = o.from_area ?? o.customer_name;
      const toArea = o.to_area ?? o.customer_phone;
      const baseAmount = o.base_amount !== null && o.base_amount !== undefined ? Number(o.base_amount) : Number(o.amount);
      const deliveryFee = o.delivery_fee !== null && o.delivery_fee !== undefined ? Number(o.delivery_fee) : 0;
      return {
        ...o,
        id: String(o.id),
        customerName: o.customer_name,
        customerPhone: o.customer_phone,
        addressText: o.address_text,
        fromArea,
        toArea,
        baseAmount,
        deliveryFee,
      };
    });
  },

  async listAvailableOrders(driverId: string) {
    const eligibility = await rpc("driver_can_take_orders", { p_driver_id: Number(driverId) });
    if (!eligibility?.can_take) return { blockedReason: eligibility?.reason || "غير مسموح", orders: [] };
    const orders = await request("orders?status=eq.AVAILABLE&is_archived=eq.false&order=created_at.desc&select=*");
    return {
      blockedReason: "",
      orders: orders.map((o: any) => {
        const fromArea = o.from_area ?? o.customer_name;
        const toArea = o.to_area ?? o.customer_phone;
        const baseAmount = o.base_amount !== null && o.base_amount !== undefined ? Number(o.base_amount) : Number(o.amount);
        const deliveryFee = o.delivery_fee !== null && o.delivery_fee !== undefined ? Number(o.delivery_fee) : 0;
        return {
          ...o,
          id: String(o.id),
          customerName: o.customer_name,
          customerPhone: o.customer_phone,
          addressText: o.address_text,
          fromArea,
          toArea,
          baseAmount,
          deliveryFee,
        };
      }),
    };
  },

  async claimOrderAtomic(orderId: string, driverId: string) {
    const updated = await request(`orders?id=eq.${orderId}&status=eq.AVAILABLE&select=id`, {
      method: "PATCH",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ status: "ASSIGNED", driver_id: Number(driverId), assigned_at: nowIso() }),
    });
    return Array.isArray(updated) && updated.length > 0;
  },

  async markPickedUp(orderId: string, driverId: string) {
    await request(`orders?id=eq.${orderId}&driver_id=eq.${driverId}&status=eq.ASSIGNED`, { method: "PATCH", body: JSON.stringify({ status: "PICKED_UP", picked_up_at: nowIso() }) });
  },

  async markDelivered(orderId: string, driverId: string) {
    await request(`orders?id=eq.${orderId}&driver_id=eq.${driverId}&or=(status.eq.ASSIGNED,status.eq.PICKED_UP)`, { method: "PATCH", body: JSON.stringify({ status: "DELIVERED", delivered_at: nowIso() }) });
  },

  async cancelOrderByDriver(orderId: string, driverId: string, reasonId: string, notes?: string) {
    const reason = await this.getCancelReasonById(reasonId);
    if (!reason) throw new Error("سبب الإلغاء غير متاح");
    await rpc("cancel_order_by_driver", {
      p_order_id: Number(orderId), p_driver_id: Number(driverId), p_cancel_reason_id: Number(reasonId), p_notes: notes || null,
    });
    return reason.penalty_points;
  },

  async getOrderForDriver(orderId: string, driverId: string) {
    const rows = await request(`orders?id=eq.${orderId}&driver_id=eq.${driverId}&select=*`);
    const order = rows[0];
    if (!order) return null;
    // Fetch the restaurant details including restaurant_name/address/phone as well as full name.
    const res = await request(
      `users?id=eq.${order.restaurant_id}&select=id,full_name,phone,restaurant_name,restaurant_address,restaurant_phone`
    );
    const restaurant = res[0];
    const fromArea = order.from_area ?? order.customer_name;
    const toArea = order.to_area ?? order.customer_phone;
    const baseAmount = order.base_amount !== null && order.base_amount !== undefined ? Number(order.base_amount) : Number(order.amount);
    const deliveryFee = order.delivery_fee !== null && order.delivery_fee !== undefined ? Number(order.delivery_fee) : 0;
    return {
      ...order,
      id: String(order.id),
      customerName: order.customer_name,
      customerPhone: order.customer_phone,
      addressText: order.address_text,
      destinationLink: order.destination_link,
      fromArea,
      toArea,
      baseAmount,
      deliveryFee,
      restaurant,
    };
  },

  async getOrderForRestaurant(orderId: string, restaurantId: string) {
    const rows = await request(`orders?id=eq.${orderId}&restaurant_id=eq.${restaurantId}&select=*`);
    const order = rows[0];
    if (!order) return null;
    const driver = order.driver_id ? (await request(`users?id=eq.${order.driver_id}&select=id,full_name,phone`))[0] : undefined;
    const fromArea = order.from_area ?? order.customer_name;
    const toArea = order.to_area ?? order.customer_phone;
    const baseAmount = order.base_amount !== null && order.base_amount !== undefined ? Number(order.base_amount) : Number(order.amount);
    const deliveryFee = order.delivery_fee !== null && order.delivery_fee !== undefined ? Number(order.delivery_fee) : 0;
    return {
      ...order,
      id: String(order.id),
      customerName: order.customer_name,
      customerPhone: order.customer_phone,
      addressText: order.address_text,
      destinationLink: order.destination_link,
      fromArea,
      toArea,
      baseAmount,
      deliveryFee,
      driver,
    };
  },

  async getDriverStatus(driverId: string) {
    const userRows = await request(`users?id=eq.${driverId}&select=id,trust_score,banned_until`);
    const user = userRows[0] || {};
    const subs = await request(`subscriptions?driver_id=eq.${driverId}&is_active=eq.true&end_at=gte.${encodeURIComponent(nowIso())}&order=end_at.desc&limit=1&select=*`);
    const active = subs[0];
    const days = active ? Math.max(0, Math.ceil((new Date(active.end_at).getTime() - Date.now()) / 86400000)) : 0;
    return { trustScore: user.trust_score ?? 0, bannedUntil: user.banned_until, subscriptionDaysRemaining: days, subscriptionActive: !!active };
  },

  /**
   * Retrieve all votes for a given order. Returns an array of objects with driver_id and is_like boolean.
   */
  async getOrderVotes(orderId: string) {
    return request(`order_votes?order_id=eq.${orderId}&select=driver_id,is_like`);
  },

  /**
   * Retrieve the current driver's votes across orders. Returns an array of objects with order_id and is_like.
   */
  async getUserVotes(driverId: string) {
    return request(`order_votes?driver_id=eq.${driverId}&select=order_id,is_like`);
  },

  /**
   * Record a like/dislike vote for an order. The backend will upsert and enforce the dislike threshold.
   */
  async recordOrderVote(orderId: string, driverId: string, isLike: boolean) {
    await rpc("record_order_vote", { p_order_id: Number(orderId), p_driver_id: Number(driverId), p_is_like: isLike });
  },

  /**
   * Reset all votes for an order and make it available again.
   */
  async resetOrderVotes(orderId: string) {
    await rpc("reset_order_votes", { p_order_id: Number(orderId) });
  },

  async getAnalytics() {
    const stats = await rpc("admin_analytics", {});
    return stats || { ordersToday: 0, deliveredToday: 0, ordersMonth: 0, activeDrivers: 0, activeSubscriptions: 0, subscriptionsIncomeTotal: 0 };
  },

  async enforcePickupTimeoutJob() {
    await rpc("enforce_pickup_timeout", {});
  },

  // ---------------------------------------------------------------------------
  // Subscription activation requests (paywall)
  /**
   * Submit a subscription activation request by the driver.
   */
  async createActivationRequest(driverId: string, plan: "WEEKLY" | "MONTHLY", screenshotUrl: string | null, note: string | null) {
    await request("subscription_activation_requests", {
      method: "POST",
      body: JSON.stringify({
        driver_id: Number(driverId),
        plan_type: plan,
        screenshot_url: screenshotUrl || null,
        note: note || null,
        status: "PENDING",
      }),
    });
  },

  /**
   * Retrieve all activation requests for admin view.
   */
  async getActivationRequests() {
    return request("subscription_activation_requests?order=created_at.desc&select=*", {});
  },

  /**
   * Approve an activation request. Plan duration days based on weekly(7) or monthly(30).
   */
  async approveActivationRequest(requestId: string, durationDays: number) {
    await rpc("approve_activation_request", { p_request_id: Number(requestId), p_duration_days: durationDays });
  },

  /**
   * Reject an activation request with note.
   */
  async rejectActivationRequest(requestId: string, note: string) {
    await rpc("reject_activation_request", { p_request_id: Number(requestId), p_admin_note: note || null });
  },

  // ---------------------------------------------------------------------------
  // Support tickets
  /**
   * Create a support ticket.
   */
  async createSupportTicket(userId: string, role: Role, title: string, description: string) {
    await request("support_tickets", {
      method: "POST",
      body: JSON.stringify({
        user_id: Number(userId),
        user_role: role,
        title,
        description,
        status: "OPEN",
      }),
    });
  },

  /**
   * List support tickets for admin.
   */
  async getSupportTickets() {
    // Join each ticket with the associated user to expose the reporter's details.
    // Selecting user:user_id(...) nests the related user record under a `user`
    // property on each ticket.  This allows the admin dashboard to display
    // who opened each ticket without additional fetches.
    return request(
      "support_tickets?order=created_at.desc&select=*,user:user_id(id,full_name,phone,role)",
      {}
    );
  },

  /**
   * List support tickets for a specific user.
   */
  async getSupportTicketsForUser(userId: string) {
    return request(`support_tickets?user_id=eq.${userId}&order=created_at.desc&select=*`, {});
  },

  /**
   * Add a message to a support ticket. senderRole should be 'ADMIN', 'DRIVER' or 'RESTAURANT'.
   */
  async addSupportMessage(ticketId: string, senderRole: Role, message: string) {
    await request("support_messages", {
      method: "POST",
      body: JSON.stringify({
        ticket_id: Number(ticketId),
        sender_role: senderRole,
        message,
      }),
    });
  },

  /**
   * Fetch messages for a support ticket.
   */
  async getSupportMessages(ticketId: string) {
    return request(`support_messages?ticket_id=eq.${ticketId}&order=created_at.asc&select=*`, {});
  },

  /**
   * Update a support ticket status (admin only)
   */
  async updateSupportTicketStatus(ticketId: string, status: "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED", adminNote?: string) {
    await request(`support_tickets?id=eq.${ticketId}`, {
      method: "PATCH",
      body: JSON.stringify({ status, admin_note: adminNote || null, updated_at: nowIso() }),
    });
  },

  // ---------------------------------------------------------------------------
  // Admin audit and error logging
  /**
   * Log a successful admin action.  The backend will insert a row into
   * admin_actions_log.  Provide an action string (e.g. "approve_registration"),
   * optional targetId (e.g. affected record) and optional meta object.
   */
  async logAdminAction(action: string, targetId?: string | null, meta?: any) {
    try {
      await rpc("log_admin_action", {
        p_admin_id: "admin-local", // since we don't have user id for admin
        p_action: action,
        p_target_id: targetId || null,
        p_meta: meta ? JSON.stringify(meta) : null,
      });
    } catch (e) {
      // swallow errors – logging should not block main flows
    }
  },

  /**
   * Log an admin error.  Pass the action name and error message/code.  The backend
   * will store this information in admin_error_logs for later auditing.
   */
  async logAdminError(action: string, message: string, errorCode?: number) {
    try {
      await rpc("log_admin_error", {
        p_admin_id: "admin-local",
        p_action: action,
        p_error_message: message,
        p_error_code: errorCode ?? null,
      });
    } catch (e) {
      // ignore errors
    }
  },

  /**
   * Change the admin password.  Generates a SHA‑256 hash of the provided
   * password and stores it in settings.admin_password_hash.  After updating,
   * the environment variables are no longer used when logging in.
   */
  async changeAdminPassword(newPassword: string) {
    const hashed = await hashPin(newPassword);
    await request("settings?id=eq.1", {
      method: "PATCH",
      body: JSON.stringify({ admin_password_hash: hashed }),
    });
  },

  /**
   * Retrieve the most recent registration for a given phone/pin combination. Returns
   * null if no registration exists or if the pin is incorrect. This is used
   * by the pending account page when verification is needed.
   */
  async getLatestRegistration(phone: string, pin: string) {
    if (!phone || !pin) return null;
    const pinHash = await hashPin(pin);
    const rows = await request(
      `registrations?phone=eq.${encodeURIComponent(phone)}&pin_hash=eq.${pinHash}&order=created_at.desc&limit=1&select=id,full_name,status,type`
    );
    if (Array.isArray(rows) && rows.length > 0) {
      const r = rows[0];
      return { id: String(r.id), fullName: r.full_name as string, status: r.status as string, type: r.type as string };
    }
    return null;
  },

  /**
   * Securely cancel a registration using phone and PIN.  Calls a backend
   * SECURITY DEFINER function that verifies the provided pin and status
   * before cancelling.  Throws if the pin is incorrect or the status is not PENDING.
   */
  async cancelRegistrationSecure(phone: string, pin: string) {
    await rpc("cancel_registration", { p_phone: phone, p_pin: pin });
  },
};
