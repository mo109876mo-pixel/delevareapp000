export interface User {
  id: number
  userId: string
  name: string
  phone: string
  email: string
  type: "restaurant" | "driver"
  status: "active" | "suspended"
}