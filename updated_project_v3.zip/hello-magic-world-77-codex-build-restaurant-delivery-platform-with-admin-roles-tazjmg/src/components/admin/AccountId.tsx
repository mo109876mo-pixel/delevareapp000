import { Button } from "@/components/ui/button"
import { Eye } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface AccountIdProps {
  userId: string
}

export const AccountId = ({ userId }: AccountIdProps) => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Eye className="h-4 w-4 text-gray-600" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>رمز الحساب</DialogTitle>
        </DialogHeader>
        <div className="p-4 bg-gray-50 rounded-lg text-center">
          <p className="text-xl font-mono">{userId}</p>
        </div>
      </DialogContent>
    </Dialog>
  )
}