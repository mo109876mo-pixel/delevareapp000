import { User } from "@/types/account"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog"

interface AccountStatusProps {
  account: User
  onStatusChange: (account: User) => void
}

export const AccountStatus = ({ account, onStatusChange }: AccountStatusProps) => {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
        >
          <X className={`h-4 w-4 ${account.status === "active" ? "text-red-600" : "text-green-600"}`} />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {account.status === "active" ? "تعليق الحساب" : "إلغاء تعليق الحساب"}
          </AlertDialogTitle>
          <AlertDialogDescription>
            هل أنت متأكد من {account.status === "active" ? "تعليق" : "إلغاء تعليق"} حساب {account.name}؟
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>إلغاء</AlertDialogCancel>
          <AlertDialogAction onClick={() => onStatusChange(account)}>
            تأكيد
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}