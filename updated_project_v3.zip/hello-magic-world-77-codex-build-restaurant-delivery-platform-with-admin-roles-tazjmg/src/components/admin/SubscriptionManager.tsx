import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import {
  Calendar,
  Clock,
  X,
  CreditCard,
  CalendarCheck,
  CalendarDays,
  Ban
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface SubscriptionManagerProps {
  userId: string
  userName: string
}

export const SubscriptionManager = ({ userId, userName }: SubscriptionManagerProps) => {
  const { toast } = useToast()
  const [remainingDays, setRemainingDays] = useState<number>(0)
  const [customDays, setCustomDays] = useState<string>("")
  const [progress, setProgress] = useState<number>(0)
  const [isActive, setIsActive] = useState<boolean>(false)

  useEffect(() => {
    if (isActive && remainingDays > 0) {
      const timer = setInterval(() => {
        setRemainingDays(prev => {
          if (prev <= 1) {
            setIsActive(false)
            clearInterval(timer)
            toast({
              title: "انتهى الاشتراك",
              description: `انتهى اشتراك ${userName}`,
            })
            return 0
          }
          return prev - 1
        })
      }, 86400000) // 24 hours

      return () => clearInterval(timer)
    }
  }, [isActive, remainingDays, userName, toast])

  useEffect(() => {
    if (remainingDays > 0) {
      const totalDays = isActive ? 30 : parseInt(customDays)
      setProgress((remainingDays / totalDays) * 100)
    }
  }, [remainingDays, isActive, customDays])

  const handleStartMonthlySubscription = (months: number) => {
    const days = months * 30
    setRemainingDays(days)
    setIsActive(true)
    toast({
      title: "تم تفعيل الاشتراك",
      description: `تم تفعيل اشتراك ${userName} لمدة ${months} ${months === 1 ? 'شهر' : 'أشهر'}`,
    })
  }

  const handleStartWeeklySubscription = () => {
    setRemainingDays(7)
    setIsActive(true)
    toast({
      title: "تم تفعيل الاشتراك",
      description: `تم تفعيل اشتراك ${userName} لمدة أسبوع`,
    })
  }

  const handleStartCustomSubscription = () => {
    const days = parseInt(customDays)
    if (days > 0) {
      setRemainingDays(days)
      setIsActive(true)
      toast({
        title: "تم تفعيل الاشتراك",
        description: `تم تفعيل اشتراك ${userName} لمدة ${days} يوم`,
      })
    }
  }

  const handleCancelSubscription = () => {
    setRemainingDays(0)
    setIsActive(false)
    setProgress(0)
    toast({
      title: "تم إلغاء الاشتراك",
      description: `تم إلغاء اشتراك ${userName}`,
      variant: "destructive",
    })
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 flex-wrap">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              اشتراك شهري
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleStartMonthlySubscription(1)}>
              <CalendarDays className="h-4 w-4 ml-2" />
              شهر واحد
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStartMonthlySubscription(3)}>
              <CalendarCheck className="h-4 w-4 ml-2" />
              ثلاثة أشهر
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStartMonthlySubscription(6)}>
              <Calendar className="h-4 w-4 ml-2" />
              ستة أشهر
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button
          onClick={handleStartWeeklySubscription}
          disabled={isActive}
          className="flex items-center gap-2"
        >
          <Calendar className="h-4 w-4" />
          اشتراك أسبوعي
        </Button>
        
        <div className="flex items-center gap-2">
          <Input
            type="number"
            value={customDays}
            onChange={(e) => setCustomDays(e.target.value)}
            placeholder="عدد الأيام"
            className="w-24"
            min="1"
          />
          <Button
            onClick={handleStartCustomSubscription}
            disabled={isActive || !customDays}
          >
            <Clock className="h-4 w-4 ml-2" />
            تفعيل
          </Button>
        </div>

        <Button
          variant="destructive"
          onClick={handleCancelSubscription}
          disabled={!isActive}
          className="flex items-center gap-2"
        >
          <Ban className="h-4 w-4" />
          إلغاء الاشتراك
        </Button>
      </div>

      {isActive && (
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-muted-foreground">
            متبقي {remainingDays} يوم
          </p>
        </div>
      )}
    </div>
  )
}