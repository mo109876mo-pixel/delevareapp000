import { User } from "@/types/account"
import { Button } from "@/components/ui/button"
import { Lock, Infinity } from "lucide-react"
import { AccountStatus } from "./AccountStatus"

interface AccountActionsProps {
  account: User
  onStatusChange: (account: User) => void
  onResetPassword: (account: User) => void
  onGrantInfinitePoints?: (account: User) => void
}

export const AccountActions = ({
  account,
  onStatusChange,
  onResetPassword,
  onGrantInfinitePoints,
}: AccountActionsProps) => {
  return (
    <div className="flex gap-2">
      <AccountStatus account={account} onStatusChange={onStatusChange} />
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onResetPassword(account)}
      >
        <Lock className="h-4 w-4 text-blue-600" />
      </Button>
      {account.type === "driver" && onGrantInfinitePoints && (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onGrantInfinitePoints(account)}
        >
          <Infinity className="h-4 w-4 text-purple-600" />
        </Button>
      )}
    </div>
  )
}