import { User } from "@/types/account"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { AccountId } from "./AccountId"
import { AccountActions } from "./AccountActions"

interface AccountsTableProps {
  accounts: User[]
  type: "restaurant" | "driver"
  onSuspend: (account: User) => void
  onResetPassword: (account: User) => void
  onGrantInfinitePoints?: (account: User) => void
}

export const AccountsTable = ({
  accounts,
  type,
  onSuspend,
  onResetPassword,
  onGrantInfinitePoints,
}: AccountsTableProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="text-right">الاسم</TableHead>
          <TableHead className="text-right">الحالة</TableHead>
          <TableHead className="text-right">رمز الحساب</TableHead>
          <TableHead className="text-right">الإجراءات</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {accounts.map((account) => (
          <TableRow key={account.id}>
            <TableCell className="font-medium">
              {account.name}
            </TableCell>
            <TableCell>
              <span className={`px-2 py-1 rounded-full text-sm ${
                account.status === "active"
                  ? "bg-green-100 text-green-800"
                  : "bg-red-100 text-red-800"
              }`}>
                {account.status === "active" ? "نشط" : "معلق"}
              </span>
            </TableCell>
            <TableCell>
              <AccountId userId={account.userId} />
            </TableCell>
            <TableCell>
              <AccountActions
                account={account}
                onStatusChange={onSuspend}
                onResetPassword={onResetPassword}
                onGrantInfinitePoints={onGrantInfinitePoints}
              />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}