import { getSessionUser, type AppRole } from "@/lib/auth";
import { Navigate } from "react-router-dom";

interface RoleGuardProps {
  role: AppRole;
  children: JSX.Element;
}

const roleDefaultPath: Record<AppRole, string> = {
  ADMIN: "/admin/dashboard",
  DRIVER: "/driver/dashboard",
  RESTAURANT: "/restaurant/dashboard",
};

const RoleGuard = ({ role, children }: RoleGuardProps) => {
  const user = getSessionUser();

  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (user.role !== role) {
    return <Navigate to={roleDefaultPath[user.role]} replace />;
  }

  return children;
};

export default RoleGuard;
