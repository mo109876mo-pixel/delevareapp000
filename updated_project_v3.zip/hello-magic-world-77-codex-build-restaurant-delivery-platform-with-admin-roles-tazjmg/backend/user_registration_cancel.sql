-- Secure registration cancellation
--
-- This script defines a security‑definer function to allow a user to cancel
-- their pending registration by providing their phone number and PIN.  The
-- function verifies the provided PIN by comparing its SHA‑256 hash with the
-- stored pin_hash on the most recent registration for that phone number.  If
-- the PIN is incorrect, or the registration status is not PENDING, an error
-- is raised.  Upon successful verification the registration status is
-- updated to REJECTED and a reject_reason is set.

create or replace function cancel_registration(p_phone text, p_pin text)
returns void
language plpgsql
security definer
as $$
declare
  reg registrations%rowtype;
  computed_hash text;
begin
  -- compute the SHA-256 hash of the provided PIN
  computed_hash := encode(digest(p_pin, 'sha256'), 'hex');
  -- get the most recent registration for this phone
  select * into reg
  from registrations
  where phone = p_phone
  order by created_at desc
  limit 1;
  if not found then
    raise exception 'Registration not found';
  end if;
  -- verify pin
  if reg.pin_hash <> computed_hash then
    raise exception 'Incorrect PIN';
  end if;
  -- verify status
  if reg.status <> 'PENDING' then
    raise exception 'Cannot cancel registration that is not pending';
  end if;
  -- perform update
  update registrations
  set status = 'REJECTED',
      reject_reason = 'تم الإلغاء من قبل المستخدم'
  where id = reg.id;
end;
$$;

-- Grant execute permission to anon so that the frontend can call this function
grant execute on function cancel_registration(text, text) to anon;