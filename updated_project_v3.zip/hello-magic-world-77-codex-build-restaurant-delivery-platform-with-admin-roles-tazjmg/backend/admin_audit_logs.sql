--
-- Admin audit and error logging (DEV/PROD) and login attempt tracking
--
-- This script defines tables and functions to audit admin actions, log errors
-- and capture login attempts.  In development environments we enable RLS and
-- grant anon broad permissions so that the frontend can insert log rows via
-- RPC without using elevated tokens.  In production you should tighten
-- these policies to restrict direct table access and only expose the
-- SECURITY DEFINER functions.  See README for details.

-- Create audit log for admin actions.  Each row records who performed the
-- action, the action string, an optional target identifier and arbitrary
-- JSON meta describing before/after state or other context.  Timestamp is
-- recorded automatically.
create table if not exists admin_actions_log (
  id bigserial primary key,
  admin_id text not null,
  action text not null,
  target_id text,
  meta jsonb,
  performed_at timestamptz not null default now()
);

-- Create error log for admin actions.  When an exception occurs during an
-- admin operation the error message and code are stored here.  This table
-- mirrors the action log but includes error details.
create table if not exists admin_error_logs (
  id bigserial primary key,
  admin_id text,
  action text,
  error_message text,
  error_code int,
  occurred_at timestamptz not null default now()
);

-- Optional table to track login attempts.  You can use this table to build
-- rate‑limiting logic in your admin login function.  Each row records the
-- attempted username, whether the attempt succeeded, the time of attempt and
-- an optional IP address.
create table if not exists admin_login_attempts (
  id bigserial primary key,
  username text not null,
  success boolean not null,
  attempted_at timestamptz not null default now(),
  ip_address text
);

-- Enable row level security on the log tables so policies can be applied.  In
-- development we create permissive policies below that allow anon to read
-- and insert.  In production you should replace these with stricter policies.
alter table admin_actions_log enable row level security;
alter table admin_error_logs enable row level security;
alter table admin_login_attempts enable row level security;

-- Development RLS policies: allow all operations for the anon role.  These
-- policies are permissive and should not be used in production.  Remove or
-- modify them to restrict access to appropriate roles.
-- Drop any existing policies to support Postgres versions lacking IF NOT EXISTS on CREATE POLICY
drop policy if exists admin_actions_dev_pol on admin_actions_log;
create policy admin_actions_dev_pol on admin_actions_log
  for all
  to anon
  using (true)
  with check (true);

drop policy if exists admin_error_dev_pol on admin_error_logs;
create policy admin_error_dev_pol on admin_error_logs
  for all
  to anon
  using (true)
  with check (true);

drop policy if exists admin_login_attempts_dev_pol on admin_login_attempts;
create policy admin_login_attempts_dev_pol on admin_login_attempts
  for all
  to anon
  using (true)
  with check (true);

-- Function to record an admin action.  Takes the admin identifier, action
-- description, optional target identifier and optional meta JSON.  Uses
-- SECURITY DEFINER so that callers with anon privileges can insert into
-- the log.  You can wrap your RPC calls or client logic to call this
-- function after each successful admin action.
create or replace function log_admin_action(
  p_admin_id text,
  p_action text,
  p_target_id text default null,
  p_meta jsonb default null
) returns void
language plpgsql
security definer
as $$
begin
  insert into admin_actions_log(admin_id, action, target_id, meta)
    values (p_admin_id, p_action, p_target_id, p_meta);
end;
$$;

grant execute on function log_admin_action(text, text, text, jsonb) to anon;

-- Function to record an admin error.  Takes the admin identifier, action
-- description, error message and optional error code.  Uses SECURITY DEFINER
-- to allow insertion via anon role.
create or replace function log_admin_error(
  p_admin_id text,
  p_action text,
  p_error_message text,
  p_error_code int default null
) returns void
language plpgsql
security definer
as $$
begin
  insert into admin_error_logs(admin_id, action, error_message, error_code)
    values (p_admin_id, p_action, p_error_message, p_error_code);
end;
$$;

grant execute on function log_admin_error(text, text, text, int) to anon;

-- Function to record an admin login attempt.  This can be used to implement
-- rate limiting by checking the number of recent failed attempts before
-- allowing another login.  IP address is optional.
create or replace function record_admin_login_attempt(
  p_username text,
  p_success boolean,
  p_ip_address text default null
) returns void
language plpgsql
security definer
as $$
begin
  insert into admin_login_attempts(username, success, ip_address)
    values (p_username, p_success, p_ip_address);
end;
$$;

grant execute on function record_admin_login_attempt(text, boolean, text) to anon;