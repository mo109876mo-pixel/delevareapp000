-- Supabase/Postgres schema for delivery platform (single city, no maps)
create extension if not exists pgcrypto;

create type user_role as enum ('ADMIN','DRIVER','RESTAURANT');
create type account_status as enum ('PENDING','APPROVED','REJECTED','SUSPENDED');
create type registration_type as enum ('DRIVER','RESTAURANT');
create type order_status as enum ('AVAILABLE','ASSIGNED','PICKED_UP','DELIVERED','CANCELED_BY_DRIVER','CANCELED_BY_RESTAURANT');
-- Activation status for subscription activation requests
create type activation_status as enum ('PENDING','APPROVED','REJECTED');

-- Support ticket status
create type support_status as enum ('OPEN','IN_PROGRESS','RESOLVED','CLOSED');
create type subscription_plan as enum ('WEEKLY','MONTHLY','FREE_TRIAL','GIFT');
create type notify_target as enum ('DRIVERS','RESTAURANTS','ALL');

create table if not exists settings (
  id int primary key default 1,
  pickup_timeout_minutes int not null default 10,
  timeout_penalty_points int not null default 5,
  free_trial_enabled boolean not null default true,
  free_trial_days int not null default 3,
  updated_at timestamptz not null default now()
);
insert into settings (id) values (1) on conflict (id) do nothing;

-- Additional CMS and feature flags on settings. These columns are added later via ALTER statements below to avoid breaking existing installs.

create table if not exists registrations (
  id bigserial primary key,
  type registration_type not null,
  full_name text not null,
  phone text not null,
  pin_hash text not null,
  gender text,
  city text,
  area text,
  restaurant_name text,
  restaurant_address text,
  restaurant_phone text,
  restaurant_notes text,
  id_card_image_path text,
  selfie_image_path text,
  status account_status not null default 'PENDING',
  reject_reason text,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id bigserial primary key,
  role user_role not null,
  full_name text not null,
  phone text unique not null,
  pin_hash text not null,
  status account_status not null default 'APPROVED',
  city text,
  area text,
  trust_score int default 100,
  banned_until timestamptz,
  restaurant_name text,
  restaurant_address text,
  restaurant_phone text,
  created_at timestamptz not null default now()
);

create table if not exists cancel_reasons (
  id bigserial primary key,
  label text not null,
  penalty_points int not null default 0,
  is_active boolean not null default true
);

create table if not exists trust_thresholds (
  id bigserial primary key,
  score_lte int not null,
  action_type text not null default 'BAN',
  ban_days int not null default 0
);

create table if not exists orders (
  id bigserial primary key,
  restaurant_id bigint not null references users(id),
  driver_id bigint references users(id),
  customer_name text not null,
  customer_phone text not null,
  address_text text not null,
  --
  -- The amount column stores the base price of the order (what the customer pays
  -- the restaurant).  The delivery fee is stored separately to make it
  -- obvious to both the restaurant and the driver how much is paid for
  -- delivery vs. the underlying order.  New columns from_area/to_area
  -- indicate pickup and dropoff areas (formerly stored in customer_name
  -- and customer_phone fields).  base_amount duplicates amount for
  -- backwards‑compatibility and to make the intention clear when
  -- selecting data from the table.
  amount numeric(12,2) not null,
  from_area text,
  to_area text,
  base_amount numeric(12,2),
  delivery_fee numeric(12,2),
  notes text,
  status order_status not null default 'AVAILABLE',
  assigned_at timestamptz,
  picked_up_at timestamptz,
  delivered_at timestamptz,
  canceled_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_orders_status on orders(status);

create table if not exists subscriptions (
  id bigserial primary key,
  driver_id bigint not null references users(id),
  plan subscription_plan not null,
  start_at timestamptz not null,
  end_at timestamptz not null,
  is_active boolean not null default true,
  amount_paid numeric(12,2) not null default 0,
  payment_note text,
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id bigserial primary key,
  target notify_target not null,
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);

-- Atomic approve registration
create or replace function approve_registration(p_registration_id bigint)
returns void
language plpgsql
security definer
as $$
declare r registrations%rowtype; s settings%rowtype; uid bigint;
begin
  select * into r from registrations where id=p_registration_id for update;
  if r.id is null or r.status <> 'PENDING' then raise exception 'registration not pending'; end if;

  insert into users(role, full_name, phone, pin_hash, status, city, area, trust_score, restaurant_name, restaurant_address, restaurant_phone)
  values (r.type::text::user_role, r.full_name, r.phone, r.pin_hash, 'APPROVED', r.city, r.area,
          case when r.type='DRIVER' then 100 else null end,
          r.restaurant_name, r.restaurant_address, r.restaurant_phone)
  returning id into uid;

  update registrations set status='APPROVED' where id=r.id;

  if r.type='DRIVER' then
    select * into s from settings where id=1;
    if s.free_trial_enabled then
      insert into subscriptions(driver_id, plan, start_at, end_at, is_active, amount_paid, payment_note)
      values(uid, 'FREE_TRIAL', now(), now() + make_interval(days => s.free_trial_days), true, 0, 'auto free trial');
    end if;
  end if;
end;
$$;

-- Driver eligibility helper
create or replace function driver_can_take_orders(p_driver_id bigint)
returns jsonb
language plpgsql
security definer
as $$
declare d users%rowtype; sub_count int;
begin
  select * into d from users where id=p_driver_id and role='DRIVER';
  if d.id is null then return jsonb_build_object('can_take', false, 'reason', 'السائق غير موجود'); end if;
  if d.banned_until is not null and d.banned_until > now() then return jsonb_build_object('can_take', false, 'reason', 'الحساب مبند'); end if;

  select count(*) into sub_count from subscriptions where driver_id=d.id and is_active=true and end_at > now();
  if sub_count = 0 then return jsonb_build_object('can_take', false, 'reason', 'الاشتراك غير فعال'); end if;

  return jsonb_build_object('can_take', true, 'reason', '');
end;
$$;

create or replace function cancel_order_by_driver(p_order_id bigint, p_driver_id bigint, p_cancel_reason_id bigint, p_notes text default null)
returns void
language plpgsql
security definer
as $$
declare ord orders%rowtype; r cancel_reasons%rowtype; d users%rowtype; th trust_thresholds%rowtype;
begin
  select * into ord from orders where id=p_order_id and driver_id=p_driver_id and status='ASSIGNED' for update;
  if ord.id is null then raise exception 'order not cancelable'; end if;

  select * into r from cancel_reasons where id=p_cancel_reason_id and is_active=true;
  if r.id is null then raise exception 'invalid reason'; end if;

  -- When a driver cancels an assigned order we make it available again.  Instead
  -- of updating the status twice (which resulted in conflicting states),
  -- perform a single update to set the order back to AVAILABLE and record the
  -- cancellation time and optional notes.  This avoids having a final
  -- status of CANCELED_BY_DRIVER immediately overwritten by AVAILABLE.
  update orders
    set status = 'AVAILABLE',
        driver_id = null,
        assigned_at = null,
        picked_up_at = null,
        canceled_at = now(),
        notes = coalesce(p_notes, notes)
    where id = ord.id;

  update users set trust_score = greatest(0, coalesce(trust_score,100) - r.penalty_points) where id=p_driver_id and role='DRIVER';
  -- log the points deduction for transparency
  insert into points_log(driver_id, reason, points_change) values (p_driver_id, r.label, -r.penalty_points);

  select * into d from users where id=p_driver_id;
  select * into th from trust_thresholds where d.trust_score <= score_lte and action_type='BAN' order by score_lte asc limit 1;
  if th.id is not null then
    update users set banned_until = now() + make_interval(days => th.ban_days) where id=p_driver_id;
  end if;
end;
$$;

create or replace function admin_analytics()
returns json
language sql
security definer
as $$
  select json_build_object(
    'ordersToday', (select count(*) from orders where created_at::date = current_date),
    'deliveredToday', (select count(*) from orders where delivered_at::date = current_date),
    'ordersMonth', (select count(*) from orders where date_trunc('month', created_at)=date_trunc('month', now())),
    'activeDrivers', (select count(*) from users where role='DRIVER' and status='APPROVED'),
    'activeSubscriptions', (select count(*) from subscriptions where is_active=true and end_at > now()),
    'subscriptionsIncomeTotal', (select coalesce(sum(amount_paid),0) from subscriptions)
  );
$$;

create or replace function enforce_pickup_timeout()
returns void
language plpgsql
security definer
as $$
declare s settings%rowtype; rec record;
begin
  select * into s from settings where id=1;
  for rec in select * from orders where status='ASSIGNED' and assigned_at < now() - make_interval(mins => s.pickup_timeout_minutes)
  loop
    update users set trust_score = greatest(0, coalesce(trust_score,100) - s.timeout_penalty_points) where id=rec.driver_id and role='DRIVER';
    update orders set status='AVAILABLE', driver_id=null, assigned_at=null where id=rec.id;
  end loop;
end;
$$;

-- RLS (when using Supabase Auth + mapped profiles)
alter table registrations enable row level security;
alter table users enable row level security;
alter table orders enable row level security;
alter table cancel_reasons enable row level security;
alter table trust_thresholds enable row level security;
alter table subscriptions enable row level security;
alter table notifications enable row level security;
alter table settings enable row level security;

-- NOTE: Policies below assume ADMIN usage through secured backend or custom JWT claims.
create policy "public can insert registrations" on registrations for insert to anon, authenticated with check (true);
create policy "users can read own orders" on orders for select to anon, authenticated using (true);

-- Extend order_status enum with UNDER_REVIEW value if missing
do $$ begin
  if not exists (select 1 from pg_enum where enumtypid = 'order_status'::regtype and enumlabel = 'UNDER_REVIEW') then
    alter type order_status add value 'UNDER_REVIEW';
  end if;
end $$;

-- Add optional website_url to users and registrations
alter table users add column if not exists website_url text;
alter table registrations add column if not exists website_url text;

-- Add destination link for orders
alter table orders add column if not exists destination_link text;

-- Add dislike threshold column to settings
alter table settings add column if not exists dislike_threshold int not null default 5;

-- Create order_votes table to store like/dislike feedback
create table if not exists order_votes (
  id bigserial primary key,
  order_id bigint not null references orders(id) on delete cascade,
  driver_id bigint not null references users(id) on delete cascade,
  is_like boolean not null,
  created_at timestamptz not null default now(),
  constraint order_votes_unique unique (order_id, driver_id)
);

-- Create points_log table to record point deductions and reasons
create table if not exists points_log (
  id bigserial primary key,
  driver_id bigint not null references users(id),
  reason text not null,
  points_change int not null,
  created_at timestamptz not null default now()
);

-- Enable row level security on new tables
alter table order_votes enable row level security;
alter table points_log enable row level security;

-- -------------------------------------------------------------------------
-- Manual subscription activation requests (paywall)
-- This table stores driver-submitted requests to activate or renew their subscription.
create table if not exists subscription_activation_requests (
  id bigserial primary key,
  driver_id bigint not null references users(id),
  plan_type subscription_plan not null,
  screenshot_url text,
  note text,
  status activation_status not null default 'PENDING',
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
alter table subscription_activation_requests enable row level security;

-- RPC to approve an activation request. The caller (admin) specifies the number of days for the plan.
create or replace function approve_activation_request(p_request_id bigint, p_duration_days int)
returns void
language plpgsql
security definer
as $$
declare req subscription_activation_requests%rowtype; end_at timestamptz; plan subscription_plan;
begin
  select * into req from subscription_activation_requests where id=p_request_id for update;
  if req.id is null or req.status <> 'PENDING' then raise exception 'activation request not pending'; end if;
  -- close current subscriptions for the driver
  update subscriptions set is_active=false where driver_id=req.driver_id and is_active=true;
  end_at := now() + make_interval(days => p_duration_days);
  plan := req.plan_type;
  -- create new subscription record
  insert into subscriptions(driver_id, plan, start_at, end_at, is_active, amount_paid, payment_note)
  values(req.driver_id, plan, now(), end_at, true, 0, 'manual activation');
  -- update request
  update subscription_activation_requests set status='APPROVED', reviewed_at=now() where id=req.id;
end;
$$;

-- RPC to reject an activation request with an admin note
create or replace function reject_activation_request(p_request_id bigint, p_admin_note text)
returns void
language plpgsql
security definer
as $$
declare req subscription_activation_requests%rowtype;
begin
  select * into req from subscription_activation_requests where id=p_request_id for update;
  if req.id is null or req.status <> 'PENDING' then raise exception 'activation request not pending'; end if;
  update subscription_activation_requests set status='REJECTED', admin_note=p_admin_note, reviewed_at=now() where id=req.id;
end;
$$;

-- -------------------------------------------------------------------------
-- Support ticketing system
-- Support tickets can be created by drivers or restaurants. Admin can respond and update status.
create table if not exists support_tickets (
  id bigserial primary key,
  user_id bigint not null references users(id),
  user_role user_role not null,
  title text not null,
  description text not null,
  status support_status not null default 'OPEN',
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table support_tickets enable row level security;

create table if not exists support_messages (
  id bigserial primary key,
  ticket_id bigint not null references support_tickets(id) on delete cascade,
  sender_role user_role not null,
  message text not null,
  created_at timestamptz not null default now()
);
alter table support_messages enable row level security;

-- There are no custom RPC functions for support tickets: reading and writing is done through RLS policies or via backend service role.
-- Basic permissive RLS policies for the new tables (anonymous key). Adjust as needed for production.
create policy "anon read/write activation requests" on subscription_activation_requests
  for all to anon, authenticated
  using (true) with check (true);

create policy "anon read/write support tickets" on support_tickets
  for all to anon, authenticated
  using (true) with check (true);

create policy "anon read/write support messages" on support_messages
  for all to anon, authenticated
  using (true) with check (true);

-- Function to record a vote and hide order if dislikes exceed threshold
create or replace function record_order_vote(p_order_id bigint, p_driver_id bigint, p_is_like boolean)
returns void
language plpgsql
security definer
as $$
declare dislike_count int; threshold int;
begin
  insert into order_votes(order_id, driver_id, is_like)
  values (p_order_id, p_driver_id, p_is_like)
  on conflict (order_id, driver_id) do update set is_like = excluded.is_like;

  select count(*) into dislike_count from order_votes where order_id = p_order_id and is_like = false;
  select dislike_threshold into threshold from settings where id=1;
  if dislike_count >= coalesce(threshold, 5) then
    update orders set status = 'UNDER_REVIEW' where id = p_order_id and status = 'AVAILABLE';
  end if;
end;
$$;

-- Function to reset votes and make order available again
create or replace function reset_order_votes(p_order_id bigint)
returns void
language plpgsql
security definer
as $$
begin
  delete from order_votes where order_id = p_order_id;
  update orders set status = 'AVAILABLE' where id = p_order_id and status = 'UNDER_REVIEW';
end;
$$;

-- -------------------------------------------------------------------------
-- Data retention & cleanup configuration
-- Add columns on orders for soft delete / archiving
alter table orders add column if not exists is_archived boolean not null default false;
alter table orders add column if not exists archived_at timestamptz;
alter table orders add column if not exists deleted_at timestamptz;

-- Add retention settings to the settings table
alter table settings add column if not exists order_retention_days_restaurant int not null default 7;
alter table settings add column if not exists order_retention_days_driver int not null default 7;
alter table settings add column if not exists order_retention_days_admin int not null default 14;
alter table settings add column if not exists votes_retention_days int;
alter table settings add column if not exists points_retention_days int;
alter table settings add column if not exists cleanup_frequency text not null default 'DAILY';

-- -------------------------------------------------------------------------
-- Additional settings for CMS and support features
-- Whether the support ticket system is enabled (drivers/restaurants can open tickets)
alter table settings add column if not exists support_enabled boolean not null default true;
-- Payment instructions for subscription activation (paywall)
alter table settings add column if not exists payment_number text;
alter table settings add column if not exists payment_howto_video_url text;
-- Privacy policy and terms content per role
alter table settings add column if not exists privacy_policy_driver text;
alter table settings add column if not exists privacy_policy_restaurant text;
alter table settings add column if not exists terms_driver text;
alter table settings add column if not exists terms_restaurant text;
-- Instructions for drivers and restaurants (text + video link)
alter table settings add column if not exists instructions_text_driver text;
alter table settings add column if not exists instructions_video_url_driver text;
alter table settings add column if not exists instructions_text_restaurant text;
alter table settings add column if not exists instructions_video_url_restaurant text;

-- Admin password hash.  In production you should store a hashed
-- administrator password in this column instead of exposing credentials via
-- environment variables.  The frontend will use this column when present.
alter table settings add column if not exists admin_password_hash text;

-- Table to record cleanup runs
create table if not exists cleanup_logs (
  id bigserial primary key,
  run_at timestamptz not null default now(),
  description text,
  orders_archived int default 0,
  votes_deleted int default 0,
  points_deleted int default 0
);
alter table cleanup_logs enable row level security;

-- Function to cleanup old records according to settings
create or replace function cleanup_old_records()
returns void
language plpgsql
security definer
as $$
declare
  s settings%rowtype;
  archived_count int;
  votes_removed int;
  points_removed int;
begin
  select * into s from settings where id = 1;
  archived_count := 0;
  votes_removed := 0;
  points_removed := 0;

  -- Archive orders older than the admin retention period
  if s.order_retention_days_admin is not null then
    update orders
      set is_archived = true,
          archived_at = now()
    where is_archived = false
      and created_at < now() - make_interval(days => s.order_retention_days_admin);
    get diagnostics archived_count = row_count;
  end if;

  -- Remove old order votes
  if s.votes_retention_days is not null then
    delete from order_votes where created_at < now() - make_interval(days => s.votes_retention_days);
    get diagnostics votes_removed = row_count;
  end if;

  -- Remove old points logs
  if s.points_retention_days is not null then
    delete from points_log where created_at < now() - make_interval(days => s.points_retention_days);
    get diagnostics points_removed = row_count;
  end if;

  -- Log cleanup operation
  insert into cleanup_logs(run_at, description, orders_archived, votes_deleted, points_deleted)
    values (now(), 'cleanup job', archived_count, votes_removed, points_removed);
end;
$$;
