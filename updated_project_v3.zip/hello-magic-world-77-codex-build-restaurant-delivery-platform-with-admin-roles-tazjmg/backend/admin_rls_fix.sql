-- ------------------------------------------------------------------------------
-- admin_rls_fix.sql
--
-- This SQL script enables row level security and grants permissive policies to
-- allow the anon key (no Supabase Auth) to perform admin operations in the
-- application.  It is intended for development/testing only.  In production
-- you should use proper authentication and SECURITY DEFINER RPCs instead of
-- exposing full table access to anonymous clients.

-- Enable RLS and create permissive policies on critical tables

-- Registrations
alter table if exists registrations enable row level security;
-- Drop any existing policy to avoid syntax errors on old Postgres versions where
-- CREATE POLICY IF NOT EXISTS is not supported. Then create a permissive
-- policy to allow the anon role (and authenticated) to perform all operations.
drop policy if exists "anon admin access registrations" on registrations;
create policy "anon admin access registrations" on registrations
  for all to anon, authenticated using (true) with check (true);

-- Users
alter table if exists users enable row level security;
drop policy if exists "anon admin access users" on users;
create policy "anon admin access users" on users
  for all to anon, authenticated using (true) with check (true);

-- Settings
alter table if exists settings enable row level security;
drop policy if exists "anon admin access settings" on settings;
create policy "anon admin access settings" on settings
  for all to anon, authenticated using (true) with check (true);

-- Orders
alter table if exists orders enable row level security;
drop policy if exists "anon admin access orders" on orders;
create policy "anon admin access orders" on orders
  for all to anon, authenticated using (true) with check (true);

-- Subscriptions
alter table if exists subscriptions enable row level security;
drop policy if exists "anon admin access subscriptions" on subscriptions;
create policy "anon admin access subscriptions" on subscriptions
  for all to anon, authenticated using (true) with check (true);

-- Cancel reasons
alter table if exists cancel_reasons enable row level security;
drop policy if exists "anon admin access cancel_reasons" on cancel_reasons;
create policy "anon admin access cancel_reasons" on cancel_reasons
  for all to anon, authenticated using (true) with check (true);

-- Trust thresholds
alter table if exists trust_thresholds enable row level security;
drop policy if exists "anon admin access trust_thresholds" on trust_thresholds;
create policy "anon admin access trust_thresholds" on trust_thresholds
  for all to anon, authenticated using (true) with check (true);

-- Order votes
alter table if exists order_votes enable row level security;
drop policy if exists "anon admin access order_votes" on order_votes;
create policy "anon admin access order_votes" on order_votes
  for all to anon, authenticated using (true) with check (true);

-- Points log
alter table if exists points_log enable row level security;
drop policy if exists "anon admin access points_log" on points_log;
create policy "anon admin access points_log" on points_log
  for all to anon, authenticated using (true) with check (true);

-- Cleanup logs
alter table if exists cleanup_logs enable row level security;
drop policy if exists "anon admin access cleanup_logs" on cleanup_logs;
create policy "anon admin access cleanup_logs" on cleanup_logs
  for all to anon, authenticated using (true) with check (true);

-- Activation requests
alter table if exists subscription_activation_requests enable row level security;
drop policy if exists "anon admin access subscription_activation_requests" on subscription_activation_requests;
create policy "anon admin access subscription_activation_requests" on subscription_activation_requests
  for all to anon, authenticated using (true) with check (true);

-- Support tickets
alter table if exists support_tickets enable row level security;
drop policy if exists "anon admin access support_tickets" on support_tickets;
create policy "anon admin access support_tickets" on support_tickets
  for all to anon, authenticated using (true) with check (true);

-- Support messages
alter table if exists support_messages enable row level security;
drop policy if exists "anon admin access support_messages" on support_messages;
create policy "anon admin access support_messages" on support_messages
  for all to anon, authenticated using (true) with check (true);

-- Notifications
alter table if exists notifications enable row level security;
drop policy if exists "anon admin access notifications" on notifications;
create policy "anon admin access notifications" on notifications
  for all to anon, authenticated using (true) with check (true);

-- Cleanup: optional grants to allow anon to execute functions
grant execute on function approve_registration(bigint) to anon;
grant execute on function record_order_vote(bigint,bigint,boolean) to anon;
grant execute on function reset_order_votes(bigint) to anon;
grant execute on function cancel_order_by_driver(bigint,bigint,bigint,text) to anon;
grant execute on function cleanup_old_records() to anon;
grant execute on function admin_analytics() to anon;
grant execute on function enforce_pickup_timeout() to anon;
grant execute on function approve_activation_request(bigint,int) to anon;
grant execute on function reject_activation_request(bigint,text) to anon;