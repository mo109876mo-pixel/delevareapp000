# API Endpoints + Server Functions + UI Routing Plan

## 1) Auth & Registration
- `POST /api/registrations/driver`
  - input: full_name, phone, pin, city, area, id_card_image, selfie_image
  - action: hash pin (argon2/bcrypt), save `registrations(status=PENDING)`.
- `POST /api/registrations/restaurant`
  - input: full_name, phone, pin, city, area, restaurant_name, restaurant_address, restaurant_phone, optional attachments
  - action: same as above.
- `GET /api/admin/registrations?status=PENDING`
- `GET /api/admin/registrations/:id`
- `POST /api/admin/registrations/:id/approve`
  - action: transactional create in `users` + `drivers/restaurants`, mark registration APPROVED.
  - if role DRIVER and `settings.free_trial_enabled = true`: create FREE_TRIAL subscription.
- `POST /api/admin/registrations/:id/reject`
  - input: reject_reason
  - action: registration -> REJECTED.
- `POST /api/auth/login`
  - input: phone, pin
  - action: verify hash, reject if PENDING/REJECTED/SUSPENDED, issue token/session.

## 2) Orders
- `POST /api/restaurant/orders` (Restaurant only)
  - create AVAILABLE order.
- `GET /api/restaurant/orders`
  - list restaurant orders with assigned driver info.
- `GET /api/driver/orders/available`
  - guards: user role DRIVER + approved + subscription active + not banned.
- `POST /api/driver/orders/:id/claim`
  - atomic SQL update where `status=AVAILABLE`.
- `POST /api/driver/orders/:id/picked-up`
  - only assigned driver can set PICKED_UP.
- `POST /api/driver/orders/:id/delivered`
  - only assigned driver can set DELIVERED.
- `POST /api/driver/orders/:id/cancel`
  - input: cancel_reason_id, optional notes
  - load penalty from `cancel_reasons`, show warning in client, then:
    - set current order CANCELED_BY_DRIVER
    - insert `order_cancellations`
    - deduct trust score
    - apply threshold punishment (`banned_until`)
    - create NEW available order copy for fast re-claim
    - add `order_events`.

## 3) Settings + Policy
- `GET /api/admin/settings`
- `PUT /api/admin/settings`
  - fields: pickup_timeout_minutes, timeout_penalty_points, free_trial_enabled, free_trial_days
- `GET /api/admin/cancel-reasons`
- `POST /api/admin/cancel-reasons`
- `PUT /api/admin/cancel-reasons/:id`
- `DELETE /api/admin/cancel-reasons/:id`
- `GET /api/admin/trust-thresholds`
- `POST /api/admin/trust-thresholds`
- `PUT /api/admin/trust-thresholds/:id`
- `DELETE /api/admin/trust-thresholds/:id`

## 4) Subscriptions
- `POST /api/admin/subscriptions/activate`
  - input: driver_id, plan(WEEKLY|MONTHLY), start_at, end_at, amount_paid, payment_note
  - deactivate overlapping subscriptions.
- `POST /api/admin/subscriptions/:id/extend`
  - manual gift days.
- `GET /api/admin/subscriptions?active=true`

## 5) Notifications
- `POST /api/admin/notifications/broadcast`
  - input: target(DRIVERS|RESTAURANTS|ALL), title, body
  - create bulk `user_notifications`.
- `GET /api/me/notifications`
- `POST /api/me/notifications/:id/read`

## 6) Analytics
- `GET /api/admin/analytics/summary`
  - returns:
    - orders_today
    - delivered_today
    - orders_month
    - active_drivers
    - active_subscriptions
    - subscriptions_income_total

## 7) Scheduler Jobs
- `job: enforcePickupTimeout` (every minute)
  - find ASSIGNED orders older than settings.pickup_timeout_minutes and not PICKED_UP.
  - for each order:
    - set status back to AVAILABLE, clear driver assignment fields
    - deduct `timeout_penalty_points`
    - apply trust thresholds and update banned_until
    - create order event + violation record.
- `job: deactivateExpiredSubscriptions` (hourly)
  - set is_active=false where end_at < now().

## 8) Frontend routing (role-based guards)
- Public:
  - `/` home
  - `/driver/auth` `/driver/login` `/driver/register`
  - `/restaurant/auth` `/restaurant/login` `/restaurant/register`
  - `/admin/login`
- Protected:
  - Driver: `/driver/dashboard`, `/driver/orders/:id`
  - Restaurant: `/restaurant/dashboard`
  - Admin: `/admin/dashboard`
- Guard rules:
  - must be logged in + role match.
  - driver routes require `subscriptionActive && !isBanned` for order visibility/claim.

## 9) Security checklist
- PIN hashing: Argon2id (preferred) or bcrypt with strong cost.
- Storage of attachments: private object storage path; never public URL.
- Admin-only signed endpoint for attachment retrieval.
- Phone uniqueness on users.
- Strict RBAC middleware on every protected endpoint.
- Audit all order transitions in `order_events`.
- Rate limit login + registration endpoints.

