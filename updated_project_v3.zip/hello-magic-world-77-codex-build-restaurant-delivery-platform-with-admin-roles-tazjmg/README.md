# Delivery Platform (Vite + React + Supabase)

This project now uses **Supabase Postgres + Storage** (instead of localStorage mock data) through REST/RPC calls with env variables.

## Environment
Create a `.env` file in the project root and provide your Supabase and admin credentials:

```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY

# Admin credentials (used only by the local admin login form).  In production you
# should set a hashed password in the `settings.admin_password_hash` column via
# the dashboard rather than relying on these values.
VITE_ADMIN_USERNAME=your_admin_username
VITE_ADMIN_PASSWORD=your_admin_password
```

> Do not hardcode keys or passwords in source code.  Environment variables are
> loaded at runtime.

## Supabase Setup

### 1) Run database schema and audit scripts
1. Open Supabase dashboard → **SQL editor**.
2. Copy/paste and execute the contents of `backend/schema.sql`.  This file defines all tables, types, functions and policies including support for subscriptions, tickets, CMS fields and cleanup routines.
3. (Optional but recommended) Copy/paste and execute `backend/admin_audit_logs.sql` to create audit and error logging tables/functions.  These functions use `SECURITY DEFINER` so they can be invoked via the anon key without elevated privileges.
4. **Development only:** execute `backend/admin_rls_fix.sql` after the above files.  This script drops any existing RLS policies and creates permissive policies allowing the anon role to read/write tables directly and to execute RPCs.  **Do not run this script in production.**

### 2) Create private storage bucket for KYC
1. Go to Storage → New bucket.
2. Bucket name: `kyc`
3. Set bucket to **Private**.

### 3) (Optional) Seed basic data
Run this once in SQL editor:

```sql
insert into cancel_reasons(label, penalty_points, is_active)
values ('تعذر الوصول للمطعم', 5, true), ('العنوان غير واضح', 8, true)
on conflict do nothing;

insert into trust_thresholds(score_lte, action_type, ban_days)
values (60,'WARNING',0),(50,'BAN',1),(30,'BAN',3),(20,'BAN',7)
on conflict do nothing;
```

### 4) Pickup-timeout scheduler
Use Supabase `pg_cron` or Edge Function scheduler to execute:

```sql
select enforce_pickup_timeout();
```

Recommended: every 1 minute.

### 5) Run app

```bash
npm install
npm run dev
```

## What was migrated
- Registrations / users / orders / settings / subscriptions / notifications are loaded from Supabase.
- Driver & Restaurant dashboards poll and refresh from backend.
- Atomic claim via SQL condition update (`status=AVAILABLE`) and returns clear failure when already claimed.
- Admin dashboard reads/writes backend data and calls RPC helpers (`approve_registration`, `admin_analytics`, `enforce_pickup_timeout`, etc.).

## New features

The platform now includes several enhancements and bug fixes:

* **Secure admin login:** Admin credentials are no longer visible in the UI.  Set your desired username and password via `.env` (`VITE_ADMIN_USERNAME` and `VITE_ADMIN_PASSWORD`).
* **Website URL for restaurants:** The restaurant registration form includes an optional `website_url` field, and the database schema stores it for both pending registrations and approved users.
* **Delivery location link:** When creating an order, restaurants can optionally provide a Google Maps link or free‑form location description.  In order details pages, a “التوجه للموقع” button opens the destination in Google Maps.
* **Like/Dislike feedback for orders:** Drivers can express whether an available order’s fare or distance is fair.  Each order card in the driver dashboard now contains 👍/👎 buttons displaying aggregated counts.  Drivers may vote once per order and can change their vote.  Votes are stored in a new `order_votes` table.  When the number of dislikes for an order reaches the threshold defined in `settings.dislike_threshold` (default 5), the order is automatically moved to an `UNDER_REVIEW` state and hidden from drivers.
* **Admin configurable dislike threshold:** The admin settings card includes a field to adjust the dislike threshold.  Updating it via the dashboard persists the value in the `settings` table.
* **Reset dislikes:** Restaurants see a warning message when their order enters the `UNDER_REVIEW` state along with a button to reset the feedback.  Resetting deletes all votes and makes the order available again so the restaurant can adjust the fare or details and republish.
* **Points log:** Penalty points resulting from driver cancellations are now recorded in a `points_log` table.  Each entry stores the driver, reason and number of points deducted for auditing.

* **Subscription activation requests:** Drivers whose subscription has expired see a paywall page.  They can choose weekly or monthly plans, upload a transfer screenshot and notes, and submit a request.  These requests are stored in `subscription_activation_requests` with a `PENDING` status.  Admins can review requests in the dashboard, approve (creating a new active subscription for 7 or 30 days) or reject with a note.

* **Support ticket system:** Drivers and restaurants can open support tickets from their dashboards when `settings.support_enabled` is true.  A support ticket stores the user, role, title, description and status.  Admins can view all tickets, update their status (OPEN → IN_PROGRESS → RESOLVED/CLOSED) and leave notes.  Additional messages can be attached via `support_messages` if you wish to extend the thread functionality.  The admin settings card includes a checkbox to enable or disable support.

* **CMS fields for privacy, terms and instructions:** The settings table now includes editable text fields for privacy policies, terms of service and instructions (text and optional video URL) separately for drivers and restaurants.  These can be edited in the admin dashboard under **إعدادات الدعم والسياسات**.  You can create dedicated pages or display these texts in your driver/restaurant dashboards as needed.

* **Privacy, terms and instruction pages:** Dedicated routes (e.g. `/driver/privacy`, `/driver/terms`, `/driver/instructions` and analogous paths for restaurants) display the content entered in settings for each role.  These pages are accessible without authentication.

* **Admin password management and audit logs:** A new field `admin_password_hash` in `settings` allows storing a hashed admin password.  The admin dashboard exposes a "تغيير كلمة المرور" action to update this hash.  All admin operations now write audit entries to `admin_actions_log`, and errors are recorded in `admin_error_logs`.  Login attempts are tracked in `admin_login_attempts`.

* **Manual subscription activation and paywall:** When a driver’s active subscription ends, the driver dashboard shows a paywall card with the payment number and a link to a payment how‑to video from settings.  The driver selects a plan, uploads a screenshot URL and note, and submits a request.  Until approved, the driver cannot see or accept available orders.

* **Support & policy settings in admin:** The admin dashboard now has a dedicated card to manage support and content settings:
  * Toggle support system on/off (`support_enabled`)
  * Update payment number and how‑to video URL used on the paywall
  * Edit privacy policy and terms text for drivers and restaurants
  * Edit instructions text and video URLs for drivers and restaurants

Refer to `backend/schema.sql` for the full DDL including the new tables and functions (`order_votes`, `points_log`, `subscription_activation_requests`, `support_tickets`, `support_messages`, `record_order_vote`, `reset_order_votes`, `approve_activation_request`, `reject_activation_request` and more).  Be sure to rerun the schema in Supabase after pulling these changes.  Without applying the updated schema, registration, paywall, support and CMS functionality will not work.

## Admin RLS and Audit Logging

During development you may want to perform administrative actions from the browser using the anon key (for example, when there is no Supabase Auth session).  By default the `settings`, `users`, `orders` and other tables are protected by row level security.  A separate SQL script `backend/admin_rls_fix.sql` enables permissive policies and grants for the anon role so that the admin dashboard can function without a service role.  **This script is only intended for local development and testing.  Do not run it in production.**

Additionally, the file `backend/admin_audit_logs.sql` introduces audit and error logging tables (`admin_actions_log`, `admin_error_logs`, `admin_login_attempts`) along with RPC functions (`log_admin_action`, `log_admin_error`, `record_admin_login_attempt`).  These functions are defined with `SECURITY DEFINER` so they can be called via anon.  In production you should keep these tables but restrict direct access via RLS and call the logging functions from your RPC procedures.

To set up logging in development, run:

```sql
-- run after executing schema.sql
\i backend/admin_audit_logs.sql
\i backend/admin_rls_fix.sql
```

In a production deployment:

* Do **not** run `admin_rls_fix.sql`.
* Ensure that only specific RPC functions (e.g. `approve_registration`, `record_order_vote`, `cleanup_old_records`) are exposed to the anon key.
* Restrict direct table access via RLS policies.
* Use the `admin_password_hash` column in `settings` to store a hashed administrator password instead of environment variables.  You can change this password from the admin dashboard.

## Data retention & auto cleanup

To prevent the database from growing indefinitely, the application now supports configurable **data retention periods** and an optional **automatic cleanup job**.

**Retention periods per role** – The `settings` table has new fields to control how long to keep data:

- `order_retention_days_restaurant`: Number of days to keep old orders visible to restaurants (default 7).
- `order_retention_days_driver`: Number of days to keep old orders visible to drivers (default 7).
- `order_retention_days_admin`: Number of days to keep orders in the active list for admins (default 14).  After this period orders are archived (soft‑deleted) and hidden from all dashboards but still retained for analytics.
- `votes_retention_days`: Optional number of days to keep like/dislike votes.  If `NULL` the votes are kept indefinitely.
- `points_retention_days`: Optional number of days to keep point‑deduction logs.  If `NULL` the logs are kept indefinitely.
- `cleanup_frequency`: How often the cleanup routine should run (`DAILY`, `WEEKLY` or `DISABLED`).  `DISABLED` means no automatic cleanup – only manual runs via the admin dashboard.

**Soft‑delete/archiving** – Orders are never permanently removed.  Instead, older orders are marked with `is_archived=true` and an `archived_at` timestamp.  Drivers and restaurants only see unarchived orders within their retention window.  Admins see a longer history according to their retention settings.  Archived orders remain in the database for reporting and auditing.

**Cleanup function** – The file `backend/schema.sql` defines a PL/pgSQL function `cleanup_old_records()` that:

1. Archives orders older than `order_retention_days_admin` by setting `is_archived=true` and `archived_at` to `now()`.
2. Deletes rows from `order_votes` older than `votes_retention_days` (when provided).
3. Deletes rows from `points_log` older than `points_retention_days` (when provided).
4. Inserts a row into `cleanup_logs` capturing the run time and counts of archived orders, deleted votes and deleted point records.

The admin dashboard includes controls to adjust these durations and run the cleanup manually.  A "سجل عمليات التنظيف" table shows when cleanup ran and how many records were archived or removed.

### Scheduling the cleanup job

Supabase will not automatically call this function on its own — you need to schedule it using one of the following options:

1. **pg_cron (Preferred)** – If your Supabase plan includes the `pg_cron` extension, you can schedule the function directly in Postgres.  For daily cleanup at midnight UTC:

   ```sql
   select cron.schedule('0 0 * * *', $$select cleanup_old_records();$$);
   ```

   To run weekly on Sundays at 02:00 UTC:

   ```sql
   select cron.schedule('0 2 * * 0', $$select cleanup_old_records();$$);
   ```

   Adjust the cron expression to suit your needs.  If `settings.cleanup_frequency` is set to `DISABLED`, you may skip scheduling.

2. **Supabase Edge Functions** – If `pg_cron` is unavailable, create an Edge Function that calls the `cleanup_old_records()` RPC and configure Supabase’s scheduler to invoke it at your desired interval.  See [Supabase documentation](https://supabase.com/docs/guides/functions/schedule-functions) for details.

You can always trigger the cleanup manually from the admin dashboard regardless of the schedule.

## Admin login

The admin portal is available at the hidden route `/secure-admin-city-portal-2026`. The application no longer exposes default credentials in the UI.  Instead, you must configure your own admin username and password via environment variables in your `.env` file:

```bash
VITE_ADMIN_USERNAME=your_admin_username
VITE_ADMIN_PASSWORD=your_admin_password
```

These values are read at runtime by the frontend and used to authenticate the admin user.  Do **not** hard‑code sensitive credentials in source code.

